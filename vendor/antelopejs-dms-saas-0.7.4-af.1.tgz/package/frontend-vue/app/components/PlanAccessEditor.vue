<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import PlanFeatureValueInput from '../build/PlanFeatureValueInput.vue'
import PlanPermissionPicker from '../build/PlanPermissionPicker.vue'
import type { CatalogFeature, PlanCatalog } from '../build/plan-catalog'
import {
	flattenPermissionTree,
	type PermissionNode,
} from '../build/plan-permissions'

interface PlanAccess {
	parentPlanId: string | null
	extraPermissions: string[]
	extraFeatures: Record<string, unknown>
}

type FeatureSource = 'inherited' | 'overridden' | 'own' | 'unset'

const FEATURES_PAGE_URL = '/modules/saas/catalog/features'
const NO_PARENT = '__none__'

const props = defineProps<{
	modelValue?: PlanAccess | null
	disabled?: boolean
	routeParams?: Record<string, string>
	permissionsTreeUrl?: string
}>()

const emit = defineEmits<{ 'update:modelValue': [value: PlanAccess] }>()

const EMPTY_CATALOG: PlanCatalog = {
	plans: [],
	features: [],
	newPlanPermissions: [],
}

const planCatalog = usePlanCatalog()
const permissionsTree = useApiData<PermissionNode[]>(
	props.permissionsTreeUrl ?? '/api/saas/plans/permissions-tree',
)
const route = useDmsRoute()
const { t } = useI18n()
const { processI18n } = useTranslation()
const { formatFeatureValue } = usePlanFeatureFormat()

const catalog = computed(() => planCatalog.data.value ?? EMPTY_CATALOG)
const tree = computed(() => permissionsTree.data.value ?? [])
const hasError = computed(() =>
	[planCatalog, permissionsTree].some((read) => read.status.value === 'error'),
)
const isPickerOpen = ref(false)

// A new plan starts with no value: no parent, nothing of its own.
function copyAccess(value: PlanAccess | null | undefined): PlanAccess {
	return {
		parentPlanId: value?.parentPlanId ?? null,
		extraPermissions: [...(value?.extraPermissions ?? [])],
		extraFeatures: { ...(value?.extraFeatures ?? {}) },
	}
}

const access = computed(() => copyAccess(props.modelValue))
const currentPlanId = computed(() => props.routeParams?.id)
const parent = computed(() =>
	catalog.value.plans.find((plan) => plan._id === access.value.parentPlanId),
)
const parentValues = computed(
	() =>
		new Map(
			(parent.value?.features ?? []).map((entry) => [
				entry.featureId,
				entry.value,
			]),
		),
)

/** Plans that can be a parent: not this one, nor one built on it. */
const parentItems = computed(() => [
	{ value: NO_PARENT, label: t('saas.catalog.editor.access.no_parent') },
	...catalog.value.plans
		.filter((plan) => plan._id !== currentPlanId.value)
		.filter(
			(plan) =>
				!currentPlanId.value || plan.inheritsFromPlanId !== currentPlanId.value,
		)
		.map((plan) => ({ value: plan._id, label: plan.name })),
])

function update(patch: Partial<PlanAccess>): void {
	emit('update:modelValue', { ...access.value, ...patch })
}

function setParent(value: string | undefined): void {
	update({ parentPlanId: !value || value === NO_PARENT ? null : value })
}

function sourceOf(feature: CatalogFeature): FeatureSource {
	const isOwn = feature._id in access.value.extraFeatures
	if (parent.value && parentValues.value.has(feature._id)) {
		return isOwn ? 'overridden' : 'inherited'
	}
	return isOwn ? 'own' : 'unset'
}

function valueOf(feature: CatalogFeature): unknown {
	if (feature._id in access.value.extraFeatures) {
		return access.value.extraFeatures[feature._id]
	}
	return parentValues.value.get(feature._id) ?? null
}

function setFeature(feature: CatalogFeature, value: unknown): void {
	update({
		extraFeatures: { ...access.value.extraFeatures, [feature._id]: value },
	})
}

function resetFeature(feature: CatalogFeature): void {
	const next = { ...access.value.extraFeatures }
	delete next[feature._id]
	update({ extraFeatures: next })
}

function parentValueLabel(feature: CatalogFeature): string {
	const value = parentValues.value.get(feature._id)
	if (feature.valueType === 'boolean') {
		return value === true
			? t('saas.catalog.editor.feature.included')
			: t('saas.catalog.editor.feature.not_included')
	}
	return formatFeatureValue({ ...feature, featureId: feature._id }, value)
}

const overriddenCount = computed(
	() =>
		catalog.value.features.filter(
			(feature) => sourceOf(feature) === 'overridden',
		).length,
)
const inheritedCount = computed(
	() =>
		catalog.value.features.filter(
			(feature) => sourceOf(feature) === 'inherited',
		).length,
)

const permissionIds = computed(() =>
	flattenPermissionTree(tree.value).map((row) => row.node.id),
)
const inheritedPermissions = computed(() => parent.value?.permissions ?? [])
const grantedPermissions = computed(() => {
	const granted = new Set([
		...access.value.extraPermissions,
		...inheritedPermissions.value,
	])
	return permissionIds.value.filter((id) => granted.has(id)).length
})
const addedPermissions = computed(() => {
	const inherited = new Set(inheritedPermissions.value)
	return access.value.extraPermissions.filter((id) => !inherited.has(id)).length
})
const permissionGroups = computed(() =>
	tree.value.map((group) => {
		const ids = [
			group.id,
			...flattenPermissionTree(group.children ?? []).map((row) => row.node.id),
		]
		const granted = new Set([
			...access.value.extraPermissions,
			...inheritedPermissions.value,
		])
		return {
			id: group.id,
			label: processI18n(group.label),
			count: `${ids.filter((id) => granted.has(id)).length}/${ids.length}`,
		}
	}),
)

const planName = computed(() => t('saas.catalog.editor.access.this_plan'))

function isBlank(value: PlanAccess): boolean {
	return (
		!value.parentPlanId &&
		value.extraPermissions.length === 0 &&
		Object.keys(value.extraFeatures).length === 0
	)
}

// A new plan starts with every permission checked, as the seeded plans hold
// them, for the operator to uncheck; a duplicate keeps the plan it copies.
// The form's value changes from the browser: until then a new plan shows the
// placeholder, on the server as in the browser's first render.
const isNewBlankPlan = !currentPlanId.value && !route.query.duplicate
const isSeeding = ref(isNewBlankPlan)
const isLoading = computed(
	() =>
		!hasError.value &&
		(isSeeding.value || !planCatalog.data.value || !permissionsTree.data.value),
)

function startNewPlanWithEveryPermission(): void {
	if (!isNewBlankPlan || !isBlank(access.value)) return
	update({ extraPermissions: catalog.value.newPlanPermissions })
}

async function load(): Promise<void> {
	await Promise.all([planCatalog.refresh(), permissionsTree.refresh()])
}

onMounted(async () => {
	await Promise.all([planCatalog, permissionsTree])
	if (planCatalog.data.value) startNewPlanWithEveryPermission()
	isSeeding.value = false
})
</script>

<template>
	<div class="flex flex-col gap-4">
		<div v-if="isLoading" class="flex flex-col gap-2">
			<USkeleton v-for="index in 4" :key="index" class="h-10 w-full" />
		</div>
		<DmsSaasLoadFailure
			v-else-if="hasError"
			:title="$t('saas.catalog.editor.access.load_failed')"
			@retry="load"
		/>
		<template v-else>
			<div class="flex flex-col gap-1.5">
				<span class="text-highlighted text-sm font-medium">
					{{ $t('saas.catalog.editor.access.parent') }}
				</span>
				<USelect
					:model-value="access.parentPlanId ?? NO_PARENT"
					:items="parentItems"
					:disabled="disabled"
					class="w-full max-w-sm"
					@update:model-value="setParent"
				/>
				<p class="text-muted text-xs">
					{{
						parent
							? $t('saas.catalog.editor.access.parent_hint', {
									parent: parent.name,
								})
							: $t('saas.catalog.editor.access.no_parent_hint')
					}}
				</p>
			</div>

			<!-- The editor sits in a form column: it lays out from its own width. -->
			<div class="border-default @container overflow-hidden rounded-lg border">
				<div
					class="bg-elevated/50 text-muted @lg:grid @lg:grid-cols-[minmax(0,1fr)_minmax(0,22rem)_9rem] hidden gap-3 px-3 py-2 text-xs font-medium uppercase"
				>
					<span>{{ $t('saas.catalog.editor.access.feature') }}</span>
					<span>{{ $t('saas.catalog.editor.access.value') }}</span>
					<span>
						{{ $t('saas.catalog.editor.access.source') }}
					</span>
				</div>
				<p
					v-if="catalog.features.length === 0"
					class="text-muted px-3 py-6 text-center text-sm"
				>
					{{ $t('saas.catalog.editor.access.no_features') }}
				</p>
				<div
					v-for="feature in catalog.features"
					:key="feature._id"
					class="border-default @lg:grid-cols-[minmax(0,1fr)_minmax(0,22rem)_9rem] @lg:gap-3 grid grid-cols-1 items-center gap-2 border-t px-3 py-2.5"
				>
					<div class="min-w-0">
						<p class="text-highlighted truncate text-sm font-medium">
							{{ feature.displayName }}
						</p>
						<p v-if="feature.description" class="text-muted truncate text-xs">
							{{ feature.description }}
						</p>
					</div>
					<PlanFeatureValueInput
						:value-type="feature.valueType"
						:model-value="valueOf(feature)"
						:unit="feature.unit"
						:disabled="disabled"
						@update:model-value="(value: unknown) => setFeature(feature, value)"
					/>
					<div class="flex items-center gap-1.5 text-xs">
						<UBadge
							v-if="sourceOf(feature) === 'inherited'"
							size="sm"
							color="neutral"
							variant="soft"
						>
							{{
								$t('saas.catalog.editor.access.inherited', {
									parent: parent?.name ?? '',
								})
							}}
						</UBadge>
						<template v-else-if="sourceOf(feature) === 'overridden'">
							<UBadge size="sm" color="primary" variant="soft">
								{{ $t('saas.catalog.editor.access.overridden') }}
							</UBadge>
							<span class="text-dimmed truncate">
								{{ parent?.name }}: {{ parentValueLabel(feature) }}
							</span>
							<UButton
								size="xs"
								color="neutral"
								variant="ghost"
								square
								icon="i-ph-arrow-counter-clockwise"
								:disabled="disabled"
								:aria-label="$t('saas.catalog.editor.access.reset')"
								:title="$t('saas.catalog.editor.access.reset')"
								@click="resetFeature(feature)"
							/>
						</template>
						<span v-else-if="sourceOf(feature) === 'unset'" class="text-dimmed">
							{{ $t('saas.catalog.editor.access.unset') }}
						</span>
					</div>
				</div>
				<div
					class="bg-elevated/50 border-default flex items-center justify-between border-t px-3 py-2 text-xs"
				>
					<span class="text-muted">
						{{
							parent
								? $t(
										'saas.catalog.editor.access.summary_parent',
										{
											count: catalog.features.length,
											overridden: overriddenCount,
											inherited: inheritedCount,
										},
										catalog.features.length,
									)
								: $t(
										'saas.catalog.editor.access.summary',
										{ count: catalog.features.length },
										catalog.features.length,
									)
						}}
					</span>
					<ULink :to="FEATURES_PAGE_URL" class="text-primary font-medium">
						{{ $t('saas.catalog.editor.access.manage_features') }}
					</ULink>
				</div>
			</div>

			<div class="border-default flex flex-col gap-3 rounded-lg border p-3">
				<div class="flex flex-wrap items-center justify-between gap-2">
					<div>
						<p class="text-highlighted text-sm font-medium">
							{{ $t('saas.catalog.editor.access.permissions') }}
						</p>
						<p class="text-muted text-xs">
							{{
								parent
									? $t('saas.catalog.editor.access.permissions_parent', {
											granted: grantedPermissions,
											total: permissionIds.length,
											parent: parent.name,
											added: addedPermissions,
										})
									: $t('saas.catalog.editor.access.permissions_summary', {
											granted: grantedPermissions,
											total: permissionIds.length,
										})
							}}
						</p>
					</div>
					<UButton
						size="sm"
						color="neutral"
						variant="outline"
						icon="i-ph-key"
						:disabled="disabled"
						@click="isPickerOpen = true"
					>
						{{ $t('saas.catalog.editor.access.edit_permissions') }}
					</UButton>
				</div>
				<div class="flex flex-wrap gap-1.5">
					<span
						v-for="group in permissionGroups"
						:key="group.id"
						class="border-default text-toned inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5 text-xs"
					>
						{{ group.label }}
						<span class="text-muted tabular-nums">{{ group.count }}</span>
					</span>
				</div>
			</div>

			<PlanPermissionPicker
				v-model:open="isPickerOpen"
				:plan-name="planName"
				:parent-name="parent?.name ?? null"
				:tree="tree"
				:own="access.extraPermissions"
				:inherited="inheritedPermissions"
				@apply="
					(permissions: string[]) => update({ extraPermissions: permissions })
				"
			/>
		</template>
	</div>
</template>
