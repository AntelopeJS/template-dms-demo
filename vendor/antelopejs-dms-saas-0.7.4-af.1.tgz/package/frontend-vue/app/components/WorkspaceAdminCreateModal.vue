<script setup lang="ts">
import { computed, onMounted, ref, watch } from 'vue'
import FormFieldRow from '../build/components/FormFieldRow.vue'
import FormRows from '../build/components/FormRows.vue'
import type { PricedPlan } from '../composables/usePlanPriceLabel'

/**
 * Creates a workspace for a customer. The operator chooses how it is paid —
 * complimentary access until a date, or by its owner at first sign-in — sees
 * whether the owner e-mail is an existing account or a new invitation, and
 * reads what will happen before anything is created. The invitation e-mail
 * leaves in the background: a failure arrives as a notification.
 */
interface PlanOption extends PricedPlan {
	_id: string
	name: string
	isActive: boolean
	isDeleted: boolean
	paymentProviderRefs?: { stripePriceId?: string } | null
}

type AccessModel = 'complimentary' | 'owner_pays'

type OwnerLookup =
	| { kind: 'existing'; name: string; workspaces: number }
	| { kind: 'new'; invitationDays: number }

type CreatedOwner =
	| { kind: 'added'; userId: string }
	| { kind: 'invited'; inviteId: string }

interface CreatedWorkspace {
	tenantId: string
	owner: CreatedOwner
	invitationEmail: 'sending' | null
}

const props = defineProps<{
	onSuccessCallback?: () => void
	onCancelCallback?: () => void
}>()

const C = 'saas.workspaces.operator_create'
const PLANS_ENDPOINT = '/api/saas/plans'
const CREATE_ENDPOINT = '/api/saas/workspaces/create'
const LOOKUP_ENDPOINT = '/api/saas/workspaces/owner-lookup'
const WORKSPACES_PATH = '/modules/saas/customers/workspaces'
const LOOKUP_DELAY_MS = 400
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

const { $authFetch } = useAuthFetch()
const { t, locale } = useI18n()
const toast = useToast()
const router = useDmsRouter()
const { resolveApiError } = useApiErrorMessage()

const plans = ref<PlanOption[]>([])
const loadError = ref<string | null>(null)
const isLoading = ref(true)
const name = ref('')
const planId = ref<string | undefined>()
const ownerEmail = ref('')
const lookup = ref<OwnerLookup | null>(null)
const access = ref<AccessModel>('complimentary')
const freeUntil = ref('')
const isSubmitting = ref(false)
const submitError = ref<string | null>(null)
let lookupTimer: ReturnType<typeof setTimeout> | undefined

const plan = computed(() =>
	plans.value.find((option) => option._id === planId.value),
)
const isPaidPlan = computed(
	() =>
		!!plan.value &&
		plan.value.price > 0 &&
		!!plan.value.paymentProviderRefs?.stripePriceId,
)
const isEmail = computed(() => EMAIL_PATTERN.test(ownerEmail.value.trim()))
const canSubmit = computed(
	() =>
		!!name.value.trim() &&
		!!planId.value &&
		isEmail.value &&
		(access.value === 'complimentary' || isPaidPlan.value) &&
		!isSubmitting.value,
)

const planPriceLabel = usePlanPriceLabel()

const planItems = computed(() =>
	plans.value.map((option) => ({
		value: option._id,
		label: `${option.name} · ${planPriceLabel(option)}`,
	})),
)

const daysLeft = computed(() =>
	freeUntil.value ? countDaysUntil(freeUntil.value, new Date()) : null,
)

function day(value: string): string {
	return formatDate(value, locale.value, { dateStyle: 'medium' }) ?? value
}

const accessItems = computed(() => [
	{
		value: 'complimentary',
		label: t(`${C}.access.complimentary`),
		description: t(`${C}.access.complimentary_description`),
	},
	{
		value: 'owner_pays',
		label: t(`${C}.access.owner_pays`),
		description: isPaidPlan.value
			? t(`${C}.access.owner_pays_description`, {
					price: plan.value ? planPriceLabel(plan.value) : '',
				})
			: t(`${C}.access.owner_pays_unavailable`),
		disabled: !isPaidPlan.value,
	},
])

const ownerSentence = computed(() => {
	const current = lookup.value
	if (!current) return ''
	return current.kind === 'existing'
		? t(`${C}.what_happens.owner_existing`, { owner: current.name })
		: t(`${C}.what_happens.owner_new`, {
				email: ownerEmail.value.trim(),
				days: current.invitationDays,
			})
})

const whatHappens = computed(() => {
	if (!name.value.trim() || !plan.value) return ''
	const base = { name: name.value.trim(), plan: plan.value.name }
	const created =
		access.value === 'owner_pays'
			? t(`${C}.what_happens.owner_pays`, {
					...base,
					price: planPriceLabel(plan.value),
				})
			: freeUntil.value
				? t(`${C}.what_happens.complimentary_until`, {
						...base,
						date: day(freeUntil.value),
					})
				: t(`${C}.what_happens.complimentary`, base)
	return [created, ownerSentence.value].filter(Boolean).join(' ')
})

const plansRead = useOnDemandRead<PlanOption[]>(() => PLANS_ENDPOINT)
const lookedUpEmail = ref('')
const ownerRead = useOnDemandRead<OwnerLookup>(
	() => (lookedUpEmail.value ? LOOKUP_ENDPOINT : null),
	{ query: () => ({ email: lookedUpEmail.value }) },
)

async function loadPlans(): Promise<void> {
	isLoading.value = true
	loadError.value = null
	try {
		const all = await plansRead.read()
		plans.value = all.filter((option) => option.isActive && !option.isDeleted)
	} catch (error) {
		loadError.value = resolveApiError(error, `${C}.load_error`)
	} finally {
		isLoading.value = false
	}
}

async function lookUpOwner(email: string): Promise<void> {
	lookedUpEmail.value = email
	try {
		const found = await ownerRead.read()
		// A newer address was typed while this one was looked up.
		if (lookedUpEmail.value === email) lookup.value = found
	} catch {
		if (lookedUpEmail.value === email) lookup.value = null
	}
}

watch(ownerEmail, (email) => {
	clearTimeout(lookupTimer)
	lookup.value = null
	if (!EMAIL_PATTERN.test(email.trim())) return
	lookupTimer = setTimeout(
		() => void lookUpOwner(email.trim()),
		LOOKUP_DELAY_MS,
	)
})

watch(isPaidPlan, (isPaid) => {
	if (!isPaid) access.value = 'complimentary'
})

function openWorkspace(tenantId: string): void {
	void router.push(`${WORKSPACES_PATH}/${tenantId}`)
}

function notifyCreated(created: CreatedWorkspace): void {
	toast.add({
		title: t(`${C}.success`),
		description:
			created.invitationEmail === 'sending'
				? t(`${C}.email_sending`)
				: undefined,
		color: 'success',
		icon: 'i-ph-check-circle',
		actions: [
			{
				label: t(`${C}.open_workspace`),
				icon: 'i-ph-arrow-right',
				onClick: () => openWorkspace(created.tenantId),
			},
		],
	})
}

async function submit(): Promise<void> {
	if (!canSubmit.value) return
	submitError.value = null
	isSubmitting.value = true
	try {
		const created = await $authFetch<CreatedWorkspace>(CREATE_ENDPOINT, {
			method: 'POST',
			body: {
				name: name.value.trim(),
				planId: planId.value,
				ownerEmail: ownerEmail.value.trim(),
				access: access.value,
				freeUntil:
					access.value === 'complimentary' ? freeUntil.value || null : null,
			},
		})
		notifyCreated(created)
		props.onSuccessCallback?.()
	} catch (error) {
		submitError.value = resolveApiError(error, `${C}.error`)
	} finally {
		isSubmitting.value = false
	}
}

onMounted(loadPlans)
</script>

<template>
	<div v-if="isLoading" class="flex flex-col gap-3">
		<USkeleton v-for="index in 4" :key="index" class="h-10 w-full" />
	</div>
	<DmsEmptyState
		v-else-if="loadError"
		variant="error"
		size="sm"
		:title="$t(`${C}.load_error`)"
		:description="loadError"
		:actions="[
			{ label: $t('saas.workspace_detail.retry'), onClick: loadPlans },
		]"
	/>
	<form v-else class="flex flex-col gap-4" @submit.prevent="submit">
		<FormRows has-required>
			<FormFieldRow
				:label="$t(`${C}.name`)"
				:help="$t(`${C}.name_help`)"
				required
			>
				<template #default="{ id }">
					<DmsInputText
						:id="id"
						v-model="name"
						:placeholder="$t(`${C}.name_placeholder`)"
						class="w-full"
						autofocus
					/>
				</template>
			</FormFieldRow>
			<FormFieldRow :label="$t(`${C}.plan`)" required>
				<template #default="{ id }">
					<DmsSelect
						:id="id"
						v-model="planId"
						:items="planItems"
						:deselectable="false"
						:placeholder="$t(`${C}.plan_placeholder`)"
						class="w-full"
					/>
				</template>
			</FormFieldRow>
			<FormFieldRow :label="$t(`${C}.owner_email`)" required>
				<template #default="{ id }">
					<DmsInputEmail
						:id="id"
						v-model="ownerEmail"
						type="email"
						:placeholder="$t(`${C}.owner_email_placeholder`)"
						class="w-full"
					/>
				</template>
				<template #help>
					<span
						v-if="lookup?.kind === 'existing'"
						class="flex items-center gap-1.5"
					>
						<UIcon name="i-ph-user-circle-check" class="text-success size-4" />
						{{
							$t(
								`${C}.owner_existing`,
								{ name: lookup.name, count: lookup.workspaces },
								lookup.workspaces,
							)
						}}
					</span>
					<span
						v-else-if="lookup?.kind === 'new'"
						class="flex items-center gap-1.5"
					>
						<UIcon name="i-ph-envelope-simple" class="size-4" />
						{{ $t(`${C}.owner_new`, { days: lookup.invitationDays }) }}
					</span>
				</template>
			</FormFieldRow>
			<FormFieldRow
				:label="$t(`${C}.access.label`)"
				:labels-control="false"
				required
			>
				<DmsChoiceCards v-model="access" :items="accessItems" />
			</FormFieldRow>
			<FormFieldRow
				v-if="access === 'complimentary'"
				:label="$t(`${C}.free_until`)"
				:help="
					daysLeft === null
						? $t(`${C}.free_until_empty`)
						: $t(`${C}.free_until_days`, { count: daysLeft }, daysLeft)
				"
			>
				<template #default="{ id }">
					<DmsDatePicker
						:id="id"
						:model-value="freeUntil || undefined"
						@update:model-value="freeUntil = $event ?? ''"
					/>
				</template>
			</FormFieldRow>
		</FormRows>
		<DmsBanner
			v-if="whatHappens"
			size="sm"
			tone="info"
			icon="i-ph-info"
			:title="$t(`${C}.what_happens.title`)"
			:description="whatHappens"
		/>
		<UAlert
			v-if="submitError"
			color="error"
			variant="subtle"
			icon="i-ph-warning-circle"
			:description="submitError"
		/>
		<div class="flex justify-end gap-2">
			<UButton
				v-if="props.onCancelCallback"
				color="neutral"
				variant="ghost"
				:disabled="isSubmitting"
				@click="props.onCancelCallback()"
			>
				{{ $t('common.cancel') }}
			</UButton>
			<UButton
				type="submit"
				color="primary"
				:loading="isSubmitting"
				:disabled="!canSubmit"
			>
				{{
					lookup?.kind === 'new' ? $t(`${C}.submit_invite`) : $t(`${C}.submit`)
				}}
			</UButton>
		</div>
	</form>
</template>
