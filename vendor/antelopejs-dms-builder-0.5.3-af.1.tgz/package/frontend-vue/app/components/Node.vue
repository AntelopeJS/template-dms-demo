<script setup lang="ts">
import { computed, ref, watch } from 'vue'
import {
	descriptorOf,
	heldChildren,
	isStructural,
	missingConfig,
	resolvedPreview,
	servedNodeAt,
	slotsOf,
} from '../runtime/catalog'
import {
	effectOfDrag,
	isRowContainer,
	namedHost,
	spansFullWidth,
} from '../runtime/dropping'
import {
	ROOM_BLOCKS,
	roomStyle,
	savedConfigAt,
	sourceKeyOf,
	withDraftEdits,
	withDraftSource,
} from '../runtime/canvas-options'
import { GUARD_BLOCK, LIVE_TOGGLE } from '../runtime/constants'
import { sourceQuery } from '../runtime/data-source'
import { joinPath } from '../runtime/draft'
import { useBuilderMode } from '../runtime/mode'
import { blockTitle } from '../runtime/naming'
import { useBuilder } from '../runtime/session'
import type { BlockDraft, ComponentPreview } from '../runtime/types'

const props = defineProps<{
	block: BlockDraft
	path: string
	preview?: ComponentPreview
}>()

const builder = useBuilder()
const session = builder.session

const descriptor = computed(() =>
	descriptorOf(session.value.catalog, props.block.type),
)
const { advanced } = useBuilderMode()
/** What the page calls the block: its title, never its name in the code. */
const title = computed(() => blockTitle(props.block, session.value.catalog))
const selected = computed(() => session.value.selection === props.path)
const hovered = computed(() => session.value.hovered === props.path)
const missing = computed(() => missingConfig(descriptor.value, props.block))
// `degraded` addresses a block the way the engine does, `<pageRef>#<path>`.
const degraded = computed(() => {
	const ref = session.value.pageRef ?? ''
	return session.value.degraded.some(
		(entry) => entry.replace(`${ref}#`, '') === props.path,
	)
})

/**
 * A block the preview stood in for renders from what the DMS served, so a table
 * shows its real columns instead of a placeholder.
 *
 * Only while the served node is this block, though. A page never compiled with
 * a required setting left empty, so a block that still has one was never the
 * one the server is serving — it is a block being built at a path something
 * else was saved at, and rendering what was saved there shows an author
 * content their draft no longer holds. Looking the path up is what could not
 * tell the two apart: re-adding a block under the name of the one it replaced
 * finds the old one every time.
 */
const served = computed(() =>
	degraded.value && !missing.value.length
		? servedNodeAt(session.value.served, props.path)
		: undefined,
)
/**
 * A block the builder cannot rewrite still shows the way the page shows it,
 * from what the DMS served, and never as the preview's stand-in, which only
 * knows it could not build it. That holds only while the block contains nothing.
 * The draft does not carry its contents, so a container would render empty.
 */
const rendered = computed(() => {
	if (props.block.preserve) {
		return served.value?.children?.length ? undefined : served.value
	}
	return served.value ?? props.preview
})
/**
 * A live page's switch draws nothing on a page that is not live, and the
 * canvas never is: it is drawn as the page will draw it, Live / Pause, so the
 * block an author placed — or the page's live setting did — is there to see.
 */
const live = computed(() => props.block.type === LIVE_TOGGLE)
const LIVE_STATES = [
	{ label: 'Live', value: 'live' },
	{ label: 'Pause', value: 'pause' },
]

/**
 * A guard is drawn as what it holds, never as the message it would show:
 * on the page, a source saying there is nothing gives the content's place to
 * the message, and the canvas is where that content is built — an author
 * cannot edit what a message stands in front of. The message is set up in its
 * container's panel.
 */
const resolved = computed(() =>
	rendered.value && props.block.type !== GUARD_BLOCK && !live.value
		? resolveDmsComponent(rendered.value.componentName)
		: undefined,
)

/**
 * What the block is rendered with: what was served for it, with the draft's
 * edits the served shape cannot carry — a setting typed since the page was
 * saved, a source measured anew — so the canvas follows the draft as it does
 * wherever the preview builds the block.
 */
const options = computed(() => {
	const shown = served.value
		? withDraftEdits(
				rendered.value?.options,
				descriptor.value,
				savedConfigAt(session.value.structure?.blocks, props.path),
				props.block.config,
			)
		: rendered.value?.options
	return withDraftSource(
		shown,
		descriptor.value,
		sourceQuery(session.value.draft, session.value.structure, props.block.name),
	)
})
const sourceKey = computed(() => sourceKeyOf(options.value, descriptor.value))
/**
 * A block that is nothing but room — a spacer — is invisible on the page, and
 * on the canvas its size would change with nothing to show it: drawn as a
 * hatched area, sized the way the page sizes it.
 */
const room = computed(() => ROOM_BLOCKS.has(props.block.type ?? ''))
const label = computed(
	() => descriptor.value?.label ?? props.block.type ?? 'Block',
)
const standInNote = computed(() =>
	missing.value.length
		? `Waiting on ${missing.value.join(', ')}`
		: 'Renders once saved — this block needs the running page',
)

const children = computed(() =>
	(props.block.children ?? []).map((child) => ({
		block: child,
		path: joinPath(props.path, child.name),
		preview: rendered.value?.children?.find((entry) => entry.id === child.name)
			?.component,
	})),
)
/**
 * What the block holds through its settings — a card's chart —, rendered inside
 * it as the page renders it. Without it a card showed its figure over nothing.
 */
const held = computed(() =>
	heldChildren(descriptor.value, rendered.value).map((child) =>
		resolvedPreview(child, resolveDmsComponent),
	),
)
const slotted = computed(() => children.value.filter((child) => child.block.slot))
const plain = computed(() => children.value.filter((child) => !child.block.slot))
/**
 * The region the rendered block is showing, reported as it changes.
 *
 * A tab set is the one container that hides part of what it holds, and it is
 * the only thing that knows which part: it exposes the tab it has open, as an
 * index into the regions its own options declare. Without this the editor would
 * go on dropping into the first tab while the author is looking at another.
 */
const instance = ref<{ activeTab?: string; goToTab?: (index: number) => void } | null>(null)
// Reported when the tab shown changes, not when the tabs do: a tab moved in the
// panel keeps its region, and the set follows it there (below).
watch(
	() => instance.value?.activeTab,
	(open) => {
		if (open === undefined) {
			return
		}
		const region = slotsOf(descriptor.value, props.block)[Number(open)]
		if (region) {
			builder.openRegion(props.path, region.id)
		}
	},
	{ immediate: true },
)

/**
 * And the other way round: a tab opened from the panel opens here too.
 *
 * Only the region asked for is watched, not the one shown, or a tab clicked on
 * the canvas would be sent back to the one the editor last held. A tab just
 * added is only rendered once the preview answers with it, so how many tabs
 * the rendered set has is watched too, and after the render.
 */
const renderedRegions = computed(() => {
	const optionPath = descriptor.value?.dynamicSlots?.optionPath
	const entries = optionPath ? options.value?.[optionPath] : undefined
	return Array.isArray(entries) ? entries.length : 0
})
watch(
	() =>
		[
			session.value.openRegions[props.path],
			slotsOf(descriptor.value, props.block).map((slot) => slot.id),
			instance.value,
			renderedRegions.value,
		] as const,
	([wanted, regions, shown]) => {
		const index = regions.indexOf(wanted ?? '')
		if (index !== -1 && shown?.goToTab && shown.activeTab !== String(index)) {
			shown.goToTab(index)
		}
	},
	{ flush: 'post' },
)

/**
 * The regions the block declares, each with what is attached to it.
 *
 * A stand-in has to answer for them itself: a container the preview has not
 * built lays no slotted child out at all, and a block just attached to a tab
 * would be missing from the canvas until the page compiles again — which is
 * exactly when a tab set stands in for itself.
 */
const regions = computed(() =>
	slotsOf(descriptor.value, props.block).map((slot) => ({
		...slot,
		children: slotted.value.filter((child) => child.block.slot === slot.id),
	})),
)
/**
 * Whether the block's own body holds nothing, and offers a way in. A tab set's
 * tabs are its body, so it has none of its own while it has a tab; a card's
 * head actions and footer are beside a body that still takes blocks.
 */
const bodyEmpty = computed(
	() =>
		!plain.value.length &&
		(!descriptor.value?.dynamicSlots || !regions.value.length),
)
/** Whether this block lays its own children out side by side. */
const inner = computed(() => isRowContainer(props.block.type))
/** Whether the editor wrote this block itself, rather than the user placing it. */
const structural = computed(() =>
	isStructural(session.value.catalog, props.block.type),
)

const dragging = computed(() => session.value.dragging !== null)
const target = computed(() => session.value.dropTarget)
/**
 * Whether the block being dragged would land in this one, as far as the user is
 * concerned: a row it would really land in belongs to the grid that wrote it,
 * and the grid is what the user put on the page.
 */
const receiving = computed(() => {
	const aimed = target.value
	if (!aimed) {
		return false
	}
	return (
		namedHost(session.value.catalog, session.value.draft, aimed.parent) ===
		props.path
	)
})
const refused = computed(() => target.value?.refusal !== undefined)
/**
 * Where the room opens when the drop is what builds the column holding it.
 *
 * A cell of a row has no place above or below it to open — that is what the
 * column is for — so the block shows the two of them inside itself, and the
 * column the drop writes is the one the user is already looking at.
 *
 * A refused target opens nothing: the border and its reason are the whole
 * answer, and room made for a block would say the drop is going to happen.
 */
const wrapGap = computed(() => {
	const wrap = refused.value ? undefined : target.value?.wrap
	if (wrap?.around !== props.path) {
		return undefined
	}
	return wrap.index === 0 ? 'before' : 'after'
})
/**
 * The way that room runs: a band above or below the block for a column, a
 * column beside it for the row a drop at its flank builds — the block giving up
 * half its width, the way it will once the row is written.
 */
const wrapAxis = computed(() => target.value?.axis ?? 'horizontal')

/**
 * Structure answers for nothing a pointer does to it: it is what the canvas
 * shows as nothing but what it holds. A click or a hover on it is one on
 * whatever holds it, and there is nothing of it to carry.
 */
function onClick(event: MouseEvent): void {
	if (structural.value) {
		return
	}
	event.stopPropagation()
	builder.select(props.path)
}

/**
 * Reached with Tab, a block is selected as a click would select it: the
 * keyboard gets the same chip, the same settings and the same keys.
 */
function onFocus(event: FocusEvent): void {
	if (structural.value || event.target !== event.currentTarget) {
		return
	}
	if (session.value.selection !== props.path) {
		builder.select(props.path)
	}
}

function onMouseEnter(event: MouseEvent): void {
	if (structural.value) {
		return
	}
	event.stopPropagation()
	builder.hover(props.path)
}
/** Whether this block is the one being carried, and so no longer quite here. */
const lifted = computed(() => session.value.dragging?.path === props.path)

/**
 * What the block's own border says, in the order the states matter: where a drop
 * would land first, then what is selected, then what the pointer is over.
 *
 * Nothing else is drawn during a drag — an outline left over from before it
 * would compete with the one target the user is aiming at.
 */
const frame = computed(() => {
	if (receiving.value) {
		// Dashed, so a refusal reads as one at a glance rather than as a target
		// drawn in another colour.
		return refused.value
			? 'outline outline-2 outline-dashed outline-error'
			: 'outline outline-2 outline-primary'
	}
	if (selected.value) {
		return 'outline outline-2 outline-primary shadow-(--dms-halo-accent)'
	}
	if (dragging.value) {
		return ''
	}
	if (hovered.value) {
		return 'outline outline-1 outline-(--dms-accent-line)'
	}
	return missing.value.length
		? 'outline outline-[1.5px] outline-dashed outline-warning'
		: ''
})

// The renderer sizes a grid from the spans its children declare, the same way
// the host's recursive renderer does — and room opened among them is one more
// column it has to divide its width by, or the block would land in a row that
// has no column for it and the others would not give any width up.
const childCount = computed(
	() =>
		children.value.reduce(
			(total, child) => total + (Number(child.block.meta?.colSpan) || 1),
			0,
		) + (gapInside.value ? 1 : 0),
)
/** Whether the room for the drop opens among this block's own children. */
const gapInside = computed(() => {
	const aimed = target.value
	return (
		aimed !== null &&
		!aimed.refusal &&
		!aimed.wrap &&
		aimed.parent === props.path
	)
})
/**
 * Placement the wrapper has to carry itself. The canvas wraps every block in a
 * div of its own for selection and outlines, so that div — not the block — is
 * what a grid lays out; a row's own `1 / -1` then applies inside the wrapper
 * and the row ends up squeezed into a single column.
 */
const spanStyle = computed(() => {
	if (spansFullWidth(props.block.type)) {
		return { gridColumn: '1 / -1' }
	}
	const span = Number(props.block.meta?.colSpan)
	return span > 1 ? { gridColumn: `span ${span}` } : undefined
})

const pageId = computed(() => session.value.structure?.page.id ?? '')

// Auto-imported from the host's own layer: the DMS titles its actions with
// translation keys, `$table.actions.export`, read in the viewer's language.
const { processI18n } = useTranslation()

/**
 * What the role the canvas is looked at as would not be shown of this block,
 * drawn the way the DMS's own role preview draws it: a hidden block under a
 * hatch, one with actions withheld marked on its edge. Only a lens — the
 * block is still edited through it.
 */
const veil = computed(() => builder.veils.value[props.path])
const veilLabel = computed(() => {
	switch (veil.value?.state) {
		case 'hidden':
			return `Hidden for ${builder.viewedAs.value?.name ?? 'this role'}`
		case 'readonly':
			return 'Read only'
		case 'limited':
			return 'Limited'
		default:
			return ''
	}
})
const veilDetail = computed(() =>
	veil.value && veil.value.state !== 'hidden'
		? `Withheld for this role: ${veil.value.withheld.map((title) => processI18n(title)).join(', ')}`
		: undefined,
)

function onDragStart(event: DragEvent): void {
	event.dataTransfer?.setData('text/plain', props.path)
	// See Library.vue: without an allowed effect the browser turns every drop
	// down before the page is asked. This one is a move, and saying `copyMove`
	// while the target answered `copy` had it drawing a copy that never happens.
	if (event.dataTransfer) {
		event.dataTransfer.effectAllowed = 'move'
	}
	// Measured now, while the block is still standing where it was: the room
	// opened for it wherever it is aimed is the room it actually takes up.
	const box = (event.currentTarget as HTMLElement).getBoundingClientRect()
	builder.beginDrag({ path: props.path, height: box.height })
}

/**
 * Read the pointer against the block it is over, on both axes.
 *
 * What each axis means is the module's to decide from the page's own shape — a
 * cell of a row answers on all four of its sides, a block the page stacks only
 * above and below — so the same gesture has to carry both. The innermost block
 * under the pointer is the one that answers, hence the stopped propagation on
 * the template's handler.
 */
function onDragOver(event: DragEvent): void {
	const box = (event.currentTarget as HTMLElement).getBoundingClientRect()
	builder.aimAt(props.path, {
		x: { start: box.left, size: box.width, at: event.clientX },
		y: { start: box.top, size: box.height, at: event.clientY },
	})
	answerCursor(event)
}

/**
 * The cursor is the only refusal an author sees before letting go, so it has to
 * say what the aim just decided rather than the browser's default — and it has
 * to say it on `dragenter` too, which is where the browser first decides what
 * to draw over an element it has just moved onto.
 */
function answerCursor(event: DragEvent): void {
	if (event.dataTransfer) {
		event.dataTransfer.dropEffect = refused.value
			? 'none'
			: effectOfDrag(session.value.dragging)
	}
}
</script>

<template>
	<!-- Laid out as a grid of one cell, for the same reason `spanStyle` exists:
	a row makes its cells as tall as the tallest, and what it stretches is this
	wrapper. The block inside would keep its own height and sit in a box it does
	not fill — a page the canvas shows and the page itself never renders. -->
	<!-- The frame is drawn inside the block: two blocks a container stacks with
	no room between them — the blocks of a tab — would otherwise have the one
	selected drawn over the edge of the next, which reads as an overlap. -->
	<div
		class="relative grid min-w-0 rounded-lg -outline-offset-2 transition-[outline-color] focus-visible:outline-2 focus-visible:outline-primary"
		:class="[
			// A block that renders to nothing yet — a tab set with no tabs, an
			// empty stack — would be a hairline nobody can click, and so could
			// neither be configured nor removed. Give it something to aim at
			// until it has content of its own. Structure is not something to
			// aim at: holding nothing, it is gone on the next edit.
			structural ? '' : 'min-h-6',
			// Room opened above or below it is a second row of this grid, and
			// the two want telling apart; room opened beside it is a second
			// column, as wide as the block.
			wrapGap ? 'gap-2' : '',
			wrapGap && wrapAxis === 'vertical' ? 'grid-flow-col auto-cols-fr' : '',
			// The block is on the pointer; what is left here is the hole it
			// came out of, which the drop is about to fill from somewhere else.
			lifted ? 'opacity-40' : '',
			room
				? 'bg-[repeating-linear-gradient(-45deg,transparent_0_6px,var(--ui-border-accented)_6px_7px)]'
				: '',
			frame,
		]"
		:style="[spanStyle, roomStyle(block.type, options)]"
		:data-path="path"
		:draggable="!structural"
		:tabindex="structural ? undefined : 0"
		:role="structural ? undefined : 'group'"
		:aria-label="structural ? undefined : `${title} · ${label}`"
		@click="onClick"
		@focus="onFocus"
		@mouseenter="onMouseEnter"
		@mouseleave="builder.hover(null)"
		@dragstart.stop="onDragStart"
		@dragend="builder.endDrag()"
		@dragenter.prevent.stop="answerCursor"
		@dragover.prevent.stop="onDragOver"
		@drop.prevent.stop="builder.drop()"
	>
		<!-- What is being aimed at, named: which container receives, and why it
		would not. -->
		<div
			v-if="receiving"
			class="absolute -top-6 left-0 z-20 flex h-5.5 items-center gap-1 whitespace-nowrap rounded-[6px_6px_6px_2px] px-2 text-[11px] font-semibold shadow-sm"
			:class="refused ? 'bg-error text-inverted' : 'bg-(--dms-accent-fill) text-(--dms-accent-on-fill)'"
			:data-drop-into="path"
		>
			<UIcon v-if="descriptor?.icon" :name="descriptor.icon" class="size-3" />
			<span>{{ title }}</span>
			<span v-if="title !== label" class="font-mono text-[10.5px] font-medium opacity-70">{{
				label
			}}</span>
			<span v-if="target?.refusal" class="font-normal">
				· {{ target.refusal }}
			</span>
		</div>

		<div
			v-if="(selected || hovered) && !dragging"
			class="absolute -top-6 left-0 z-10 flex h-5.5 items-center gap-1 rounded-[6px_6px_6px_2px] pr-0.5 pl-2 text-[11px] font-semibold whitespace-nowrap shadow-sm"
			:class="
				selected
					? 'bg-(--dms-accent-fill) text-(--dms-accent-on-fill)'
					: 'border border-(--dms-accent-line) bg-elevated text-toned'
			"
		>
			<UIcon v-if="descriptor?.icon" :name="descriptor.icon" class="size-3" />
			<span>{{ title }}</span>
			<span v-if="advanced" class="font-mono text-[10.5px] font-medium opacity-70">
				#{{ block.name }}
			</span>
			<!-- A block the builder cannot rewrite carries no type in the draft,
			so its label would only say "Block". -->
			<template v-if="block.preserve">
				<span class="opacity-70">·</span>
				<UIcon name="i-ph-lock-simple-light" class="size-3 opacity-70" />
				<span class="opacity-70">set up in code</span>
			</template>
			<template v-else>
				<span v-if="title !== label" class="font-mono text-[10.5px] font-medium opacity-70">{{
					label
				}}</span>
				<span v-if="served" class="font-mono text-[10.5px] font-medium opacity-70">· as saved</span>
			</template>
			<UIcon
				v-if="missing.length"
				name="i-ph-warning-light"
				class="size-3 text-warning"
			/>
			<button
				type="button"
				class="ml-0.5 grid h-4.5 w-5 place-items-center rounded bg-current/10 hover:bg-current/20"
				aria-label="Block actions"
				@click.stop="
					builder.openMenu(
						path,
						($event.currentTarget as HTMLElement).getBoundingClientRect().left,
						($event.currentTarget as HTMLElement).getBoundingClientRect()
							.bottom + 6,
					)
				"
			>
				<UIcon name="i-ph-dots-three-light" class="size-3.5" />
			</button>
		</div>

		<DmsBuilderPlaceholder v-if="wrapGap === 'before'" :axis="wrapAxis" />

		<!-- Said for whoever is building the page: why the code cannot be
		rewritten, and where it lives, are for the panel's developer notes. -->
		<div
			v-if="block.preserve && !resolved"
			class="flex items-center gap-2 rounded-lg border border-dashed border-default bg-elevated p-4 text-sm text-dimmed"
		>
			<UIcon name="i-ph-lock-simple-light" class="size-4" />
			<span>{{ block.name }} is set up in code and can't be changed here</span>
		</div>

		<div v-else-if="live" class="flex items-center gap-2 py-1" data-live-stand-in>
			<DmsSegmented
				model-value="live"
				:items="LIVE_STATES"
				size="xs"
				aria-label="Live or paused"
				class="pointer-events-none"
			/>
			<span class="text-xs text-dimmed">updated just now</span>
		</div>

		<!-- Structure the editor wrote for itself stands in as nothing but what
		it holds, laid out the way it lays it out: naming it would teach the user
		the one word the gesture that built it exists to spare them. -->
		<div
			v-else-if="!resolved && structural"
			class="flex gap-2"
			:class="inner ? 'flex-row' : 'flex-col'"
		>
			<!-- No way in: structure holding nothing is removed on the next edit,
			and a box offering to be filled would be the one thing it shows. -->
			<DmsBuilderChildren :path="path" :children="plain" />
		</div>

		<!-- A container the preview has not answered for yet — a stack just
		added — still has to be fillable, so it stands in for itself and keeps
		holding its children. -->
		<div
			v-else-if="!resolved && descriptor?.container"
			class="flex flex-col gap-2 rounded-lg border border-dashed border-default bg-elevated p-4"
		>
			<span class="text-xs text-dimmed">
				<span class="font-medium text-default">{{ label }}</span>
				— {{ standInNote }}
			</span>
			<div class="flex flex-col gap-2">
				<!-- Named, so the tabs of a set the preview cannot build are told
				apart by what the author called them. -->
				<div
					v-for="region in regions"
					:key="region.id"
					class="flex flex-col gap-1"
					:data-region="region.id"
				>
					<span class="text-xs font-medium text-dimmed">{{ region.label }}</span>
					<DmsBuilderChildren
						:path="path"
						:children="region.children"
						:empty="!region.children.length"
						:region="region.id"
					/>
				</div>
				<DmsBuilderChildren
					:path="path"
					:children="plain"
					:empty="bodyEmpty"
				/>
			</div>
		</div>

		<div
			v-else-if="!resolved"
			class="flex flex-col items-center gap-1 rounded-lg border-[1.5px] border-dashed p-6 text-center text-sm"
			:class="
				missing.length
					? 'border-warning/50 bg-warning/5 text-muted'
					: 'border-default bg-elevated text-dimmed'
			"
		>
			<span class="font-medium text-default">{{ label }}</span>
			<span>{{ standInNote }}</span>
			<!-- What it waits on is a click away: the settings it lacks. -->
			<UButton
				v-if="missing.length"
				label="Fill it in"
				size="xs"
				color="warning"
				variant="soft"
				class="mt-1"
				@click.stop="builder.select(path)"
			/>
		</div>

		<DmsBuilderBoundary v-else :label="label" :reset-key="options">
			<!-- A DMS component may await in its own setup — a form asks for its
			values before it can render a field, a table for its rows — and Vue
			refuses to mount an async setup that has no Suspense above it: it warns
			once per render and mounts nothing, which takes the editor down with
			it. A page is rendered inside one; the canvas renders the same
			components itself, so it carries its own. -->
			<Suspense>
				<component
					:is="resolved"
					:key="sourceKey"
					ref="instance"
					v-bind="options"
					:page-id="pageId"
					:component-id="path"
					:child-count="childCount"
				>
					<template v-for="region in regions" :key="region.id" #[region.id]>
						<DmsBuilderChildren
							:path="path"
							:children="region.children"
							:empty="!region.children.length"
							:region="region.id"
							:label="region.label"
						/>
					</template>
					<template #default>
						<!-- Keyed on what it draws: a chart switched from columns to a pie in
						place keeps the one colour its single series had, where the page,
						drawing it afresh, gives each slice its own. -->
						<DmsRecursiveComponent
							v-for="child in held"
							:key="`${child.id}:${JSON.stringify(child.options)}`"
							:component="child"
							:page-id="pageId"
							:component-id="`${path}-child-${child.id}`"
						/>
						<DmsBuilderChildren
							:path="path"
							:children="plain"
							:empty="!structural && descriptor?.container === true && bodyEmpty"
						/>
					</template>
				</component>
			</Suspense>
		</DmsBuilderBoundary>

		<DmsBuilderPlaceholder v-if="wrapGap === 'after'" :axis="wrapAxis" />

		<template v-if="veil">
			<div
				v-if="veil.state === 'hidden'"
				class="pointer-events-none absolute inset-0 z-[5] rounded-[inherit] bg-[repeating-linear-gradient(-45deg,color-mix(in_srgb,var(--ui-bg)_84%,transparent)_0_10px,color-mix(in_srgb,var(--ui-bg)_70%,transparent)_10px_20px)] backdrop-blur-[3px]"
				data-veil="hidden"
			/>
			<UTooltip :text="veilDetail" :disabled="!veilDetail">
				<span
					class="absolute z-[6] inline-flex h-6 items-center gap-1.5 rounded-full border px-2.5 font-mono text-[10.5px] font-[650] tracking-[0.08em] whitespace-nowrap uppercase backdrop-blur-md"
					:class="
						veil.state === 'hidden'
							? 'pointer-events-none top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 border-(--dms-error-line) bg-(--dms-error-tint) text-error'
							: '-top-3 right-4 border-(--dms-warning-line) text-warning [background:linear-gradient(var(--dms-warning-tint),var(--dms-warning-tint)),var(--ui-bg)]'
					"
					role="status"
					:tabindex="veilDetail ? 0 : undefined"
					:data-veil-badge="veil.state"
				>
					<UIcon
						:name="veil.state === 'hidden' ? 'i-ph-lock-simple' : 'i-ph-eye'"
						class="size-[13px] shrink-0"
					/>
					{{ veilLabel }}
				</span>
			</UTooltip>
		</template>
	</div>
</template>
