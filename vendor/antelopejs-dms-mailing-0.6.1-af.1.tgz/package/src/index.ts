import "./permissions";
import "./db";
import { ImplementInterface } from "@antelopejs/interface-core";
import { AddFrontendModule } from "@antelopejs/interface-dms/page";
import {
  registerAutomationNodes,
  unregisterAutomationNodes,
} from "./automation";
import { type DmsMailingConfig, setConfig } from "./config";
import {
  ATTENTION_JOB,
  RETENTION_JOB,
  type ScheduledJob,
  scheduleJob,
  stopJob,
} from "./crons";
import {
  registerDatabaseReady,
  registerTenantExport,
  unregisterTenantExport,
} from "./hooks";
import { registerRealtimeTopics } from "./realtime";
import { frontendModule } from "./frontend-module";

export * from "./data";
export * from "./data-types";
export * from "./pages";
export * from "./quick-actions";
export * from "./routes";
export type { DmsMailingConfig } from "./config";

const CRON_JOBS = [RETENTION_JOB, ATTENTION_JOB];

let scheduledJobs: ScheduledJob[] = [];

export async function construct(config: DmsMailingConfig = {}): Promise<void> {
  registerDatabaseReady();
  setConfig(config);
  ImplementInterface(
    await import("@antelopejs/interface-dms-mailing"),
    await import("./implementations/dms-mailing"),
  );
  registerAutomationNodes();
  registerTenantExport();
  registerRealtimeTopics();
  await AddFrontendModule(frontendModule());
}

export function destroy(): void {
  unregisterAutomationNodes();
  unregisterTenantExport();
}

export function start(): void {
  scheduledJobs = CRON_JOBS.map(scheduleJob);
}

export async function stop(): Promise<void> {
  const jobs = scheduledJobs;
  scheduledJobs = [];
  await Promise.all(jobs.map(stopJob));
}
