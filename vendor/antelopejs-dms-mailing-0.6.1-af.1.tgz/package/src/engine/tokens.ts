import { getPath, isPresent } from "./paths";

export const TOKEN_PATTERN = /\{\{\s*([A-Za-z0-9_.[\]]+)\s*\}\}/g;

/**
 * How a token without a value prints. `preview` keeps it visible so an author
 * sees what is missing; `send` blanks it, so a recipient never reads braces.
 */
export type InterpolationMode = "preview" | "send";

export interface InterpolationResult {
  text: string;
  missing: string[];
}

const MISSING_TOKEN: Record<InterpolationMode, (token: string) => string> = {
  preview: (token) => token,
  send: () => "",
};

export function extractTokens(text: string): string[] {
  const found = new Set<string>();
  for (const match of text.matchAll(TOKEN_PATTERN))
    found.add(match[1] as string);
  return [...found];
}

function formatValue(value: unknown): string {
  return value instanceof Date ? value.toISOString() : String(value);
}

export function interpolate(
  text: string,
  data: Record<string, unknown>,
  mode: InterpolationMode = "preview",
): InterpolationResult {
  const missing = new Set<string>();
  const output = text.replace(TOKEN_PATTERN, (token, path: string) => {
    const value = getPath(data, path);
    if (!isPresent(value)) {
      missing.add(path);
      return MISSING_TOKEN[mode](token);
    }
    return formatValue(value);
  });
  return { text: output, missing: [...missing] };
}
