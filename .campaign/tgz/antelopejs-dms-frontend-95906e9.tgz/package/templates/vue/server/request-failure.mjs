import { isNumber, isObjectLike } from "./type-guards.mjs";

const FRONTEND_ORIGIN = "http://frontend.local";
const TEXT_TYPE = "text/plain; charset=utf-8";

/**
 * Whether the path of `url` holds a percent-escape no decoder accepts, such as
 * `/projects/%E0%A4%A`. Vite and the router decode the path, and throw on it.
 *
 * @param {string} url
 */
export function hasMalformedPath(url) {
  try {
    decodeURI(new URL(url, FRONTEND_ORIGIN).pathname);
    return false;
  } catch {
    return true;
  }
}

/**
 * The status an error asks to be answered with: its integer `status`, else 502.
 *
 * @param {unknown} error
 * @returns {number}
 */
export function failureStatus(error) {
  const status = isObjectLike(error) ? error.status : undefined;
  return isNumber(status) && Number.isInteger(status) ? status : 502;
}

/**
 * Whether a failed request can no longer be answered: the client went away, or
 * the response already started.
 *
 * @param {unknown} error
 * @param {import("node:http").ServerResponse} response
 */
export function isResponseGone(error, response) {
  return (
    error?.code === "ERR_STREAM_PREMATURE_CLOSE" ||
    response.destroyed ||
    response.writableEnded ||
    response.headersSent
  );
}

/**
 * Answers for requests the server cannot serve at all: an unreadable URL, or
 * a failure while it was already rendering the error page.
 *
 * @param {import("node:http").ServerResponse} response
 */
export function writeBadRequest(response) {
  response.writeHead(400, { "content-type": TEXT_TYPE });
  response.end("Bad Request");
}

/**
 * The last resort once even the error page failed: a bare 500, or a dropped
 * connection when the response already started. The server keeps running
 * either way.
 *
 * @param {unknown} error
 * @param {import("node:http").ServerResponse} response
 */
export function abandonResponse(error, response) {
  console.error("DMS error response failed", error);
  if (response.headersSent || response.writableEnded) {
    response.destroy();
    return;
  }
  response.writeHead(500, { "content-type": TEXT_TYPE });
  response.end("Internal Server Error");
}
