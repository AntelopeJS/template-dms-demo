import type {
	OfferedPlanView,
	SeatsInUse,
	TenantPlanFeature,
} from './useTenantPlan'
import { PLAN_UNLIMITED } from '../build/plan-catalog'

/** Query parameter naming the plan to review on arrival on the billing page. */
export const UPGRADE_QUERY_PARAM = 'upgrade'

const INCOMPATIBLE_CODE = 'saas.errors.plan.incompatible'

const UNLIMITED_RANK = Number.POSITIVE_INFINITY

/** One feature that differs between two plans. */
export interface PlanFeatureChange {
	feature: TenantPlanFeature
	from: unknown
	to: unknown
}

/** What moving between two plans gives and takes away. */
export interface PlanFeatureDiff {
	gained: PlanFeatureChange[]
	lost: PlanFeatureChange[]
}

/**
 * Plans the workspace may move to, those reserved to the other customer type,
 * and those its seats rule out.
 */
export interface OfferedPlans {
	offered: OfferedPlanView[]
	forOtherCustomerType: OfferedPlanView[]
	tooSmall: OfferedPlanView[]
}

/** Where the checkout dialog stands before it may send the owner to pay. */
export interface CheckoutReadiness {
	isLoading: boolean
	hasLoadFailed: boolean
	/** Translated reason the preview was refused, null once it priced. */
	previewFailure: string | null
}

/**
 * Whether the checkout dialog may offer the payment page: the identity is
 * loaded and the plan change was not refused while previewed — the checkout
 * itself would refuse it for the same reason.
 */
export function canContinueToCheckout(readiness: CheckoutReadiness): boolean {
	return (
		!readiness.isLoading &&
		!readiness.hasLoadFailed &&
		readiness.previewFailure === null
	)
}

/** Something the workspace holds that the target plan does not allow. */
export interface PlanChangeIncompatibility {
	code: string
	message: string
	resource?: string
}

/**
 * What the workspace must bring within the target plan before it can move,
 * read from the 409 a plan change preview or confirmation answers with; null
 * for any other failure.
 */
export function readPlanChangeIncompatibilities(
	error: unknown,
): PlanChangeIncompatibility[] | null {
	const data = (error as { data?: unknown } | undefined)?.data as
		| { code?: unknown; incompatibilities?: unknown }
		| undefined
	if (data?.code !== INCOMPATIBLE_CODE) return null
	const list = data.incompatibilities
	return Array.isArray(list) ? (list as PlanChangeIncompatibility[]) : null
}

/**
 * The plan id an arrival link asks to review (`?upgrade=<planId>`), or null.
 * A repeated parameter takes its first non-empty value.
 */
export function readUpgradeParam(
	query: Record<string, unknown> | null | undefined,
): string | null {
	const raw = query?.[UPGRADE_QUERY_PARAM]
	const values = Array.isArray(raw) ? raw : [raw]
	const planId = values.find(
		(value): value is string =>
			typeof value === 'string' && value.trim().length > 0,
	)
	return planId?.trim() ?? null
}

/** Whether a plan's seat cap holds the seats in use (negative means no cap). */
export function fitsSeats(plan: OfferedPlanView, seats: SeatsInUse): boolean {
	return plan.maxMembers <= PLAN_UNLIMITED || plan.maxMembers >= seats.occupied
}

/**
 * The plans offered in the comparison: those sold to the customer type that
 * the seats in use fit, the current one always; the rest are named apart,
 * with why they are not offered. The plan change refuses them anyway.
 */
export function splitOfferedPlans(
	plans: OfferedPlanView[],
	seats: SeatsInUse,
	currentPlanId: string | null,
): OfferedPlans {
	const others = plans.filter((plan) => plan._id !== currentPlanId)
	const forOtherCustomerType = others.filter(
		(plan) => !plan.isOfferedToCustomerType,
	)
	const tooSmall = others.filter(
		(plan) => plan.isOfferedToCustomerType && !fitsSeats(plan, seats),
	)
	const excluded = new Set([...forOtherCustomerType, ...tooSmall])
	return {
		offered: plans.filter((plan) => !excluded.has(plan)),
		forOtherCustomerType,
		tooSmall,
	}
}

/**
 * How much of a feature a value grants: not included (absent, `false`, 0),
 * a limit (its number), unlimited (−1), included (`true`). Text values have
 * no order and rank as included.
 */
export function featureRank(value: unknown): number {
	if (value === undefined || value === null || value === false) return 0
	if (value === true) return 1
	if (typeof value === 'number') {
		return value === PLAN_UNLIMITED ? UNLIMITED_RANK : Math.max(value, 0)
	}
	return typeof value === 'string' && value.trim() ? 1 : 0
}

/** The features gained and lost when moving from one plan to another. */
export function diffPlanFeatures(
	features: TenantPlanFeature[],
	from: OfferedPlanView | null,
	to: OfferedPlanView,
): PlanFeatureDiff {
	const diff: PlanFeatureDiff = { gained: [], lost: [] }
	for (const feature of features) {
		const before = from?.featureValues[feature.featureId]
		const after = to.featureValues[feature.featureId]
		// Ranks are compared, not subtracted: two unlimited values are both
		// Infinity, and Infinity - Infinity is NaN, which read as a loss.
		const rankBefore = featureRank(before)
		const rankAfter = featureRank(after)
		if (rankAfter === rankBefore) continue
		const change = { feature, from: before, to: after }
		;(rankAfter > rankBefore ? diff.gained : diff.lost).push(change)
	}
	return diff
}
