import { mkdirSync, mkdtempSync, rmSync, symlinkSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { build, type Plugin } from 'vite'
import { afterEach, beforeEach, expect, it } from 'vitest'
import { backendBoundary } from '../build/backend-boundary.ts'

let root: string
beforeEach(() => {
	root = mkdtempSync(join(tmpdir(), 'dms-builder-boundary-'))
	mkdirSync(join(root, 'backend/src'), { recursive: true })
	mkdirSync(join(root, 'backend/dist'), { recursive: true })
	mkdirSync(join(root, 'frontend'), { recursive: true })
	writeFileSync(join(root, 'backend/package.json'), JSON.stringify({ name: '@antelopejs/dms-builder' }))
	writeFileSync(join(root, 'backend/src/api.ts'), 'export const api = 1;\n')
	writeFileSync(join(root, 'backend/dist/api.ts'), 'export const api = 2;\n')
	mkdirSync(join(root, 'backend/srcx'), { recursive: true })
	writeFileSync(join(root, 'backend/srcx/api.ts'), 'export const api = 4;\n')
	mkdirSync(join(root, 'backend/dist/src'), { recursive: true })
	writeFileSync(join(root, 'backend/dist/src/api.ts'), 'export const api = 5;\n')
})
afterEach(() => rmSync(root, { recursive: true, force: true }))

function bundle(entry: string, extra: Plugin[] = [], external?: (id: string) => boolean) {
	writeFileSync(join(root, 'frontend/entry.ts'), entry)
	return build({
		root,
		logLevel: 'silent',
		configFile: false,
		plugins: [backendBoundary(), ...extra],
		build: {
			write: false,
			lib: { entry: join(root, 'frontend/entry.ts'), formats: ['es'] },
			rollupOptions: { external },
		},
	})
}

it('fails on an import of the backend source and names both files', async () => {
	const failing = bundle('import { api } from "../backend/src/api";\nexport default api;\n')
	await expect(failing).rejects.toThrow(join(root, 'frontend/entry.ts'))
	await expect(failing).rejects.toThrow(join(root, 'backend/src/api.ts'))
})

it('accepts another file of the backend package', async () => {
	await expect(
		bundle('import { api } from "../backend/dist/api";\nexport default api;\n'),
	).resolves.toBeDefined()
})

it('accepts a backend directory whose name only starts with src', async () => {
	await expect(
		bundle('import { api } from "../backend/srcx/api";\nexport default api;\n'),
	).resolves.toBeDefined()
})

it('accepts a src directory deeper in the backend package', async () => {
	await expect(
		bundle('import { api } from "../backend/dist/src/api";\nexport default api;\n'),
	).resolves.toBeDefined()
})

it('fails on a backend source file the build marks external', async () => {
	const failing = bundle('import { api } from "../backend/src/api";\nexport default api;\n', [], (id) =>
		id.startsWith(join(root, 'backend/src')),
	)
	await expect(failing).rejects.toThrow('Backend boundary')
	await expect(failing).rejects.toThrow(join(root, 'backend/src/api.ts'))
})

it('ignores a virtual module', async () => {
	const virtual: Plugin = {
		name: 'virtual-fixture',
		resolveId: (source) => (source === 'virtual:fixture' ? '\0fixture' : null),
		load: (id) => (id === '\0fixture' ? 'export default 1;' : null),
	}
	await expect(
		bundle('import one from "virtual:fixture";\nexport default one;\n', [virtual]),
	).resolves.toBeDefined()
})

function resolvingTo(target: () => string): Plugin {
	return {
		name: 'fixture-resolver',
		resolveId: (source) => (source === 'fixture:target' ? target() : null),
	}
}

const IMPORT_TARGET = 'import { api } from "fixture:target";\nexport default api;\n'

it('follows a symlink the resolver returns to the backend source', async () => {
	symlinkSync(join(root, 'backend/src/api.ts'), join(root, 'frontend/linked.ts'))
	const failing = bundle(IMPORT_TARGET, [resolvingTo(() => join(root, 'frontend/linked.ts'))])
	await expect(failing).rejects.toThrow('Backend boundary')
	await expect(failing).rejects.toThrow(join(root, 'backend/src/api.ts'))
})

it('sees through a query on the resolved id', async () => {
	const failing = bundle(IMPORT_TARGET, [resolvingTo(() => `${join(root, 'backend/src/api.ts')}?raw`)])
	await expect(failing).rejects.toThrow('Backend boundary')
	await expect(failing).rejects.toThrow(join(root, 'backend/src/api.ts'))
})

it('sees through a hash on the resolved id', async () => {
	const failing = bundle(IMPORT_TARGET, [resolvingTo(() => `${join(root, 'backend/src/api.ts')}#fragment`)])
	await expect(failing).rejects.toThrow('Backend boundary')
	await expect(failing).rejects.toThrow(join(root, 'backend/src/api.ts'))
})

it('lets the owning package decide, not the directory name', async () => {
	mkdirSync(join(root, 'other/src'), { recursive: true })
	writeFileSync(join(root, 'other/package.json'), JSON.stringify({ name: '@acme/other' }))
	writeFileSync(join(root, 'other/src/api.ts'), 'export const api = 3;\n')
	await expect(
		bundle('import { api } from "../other/src/api";\nexport default api;\n'),
	).resolves.toBeDefined()
})
