<script setup lang="ts">
import { computed, ref, watch } from 'vue'
import {
	ADVANCED_OPTION_GROUP,
	CONTROLLER_SETTING,
	descriptorOf,
	missingSettings,
	offeredIn,
	optionGroups,
	slotsOf,
} from '../runtime/catalog'
import { FIELD_ROW, GUARDED_BLOCKS } from '../runtime/constants'
import { findNode, parentPath } from '../runtime/draft'
import { PANEL_CARD } from '../runtime/form-panel'
import { useBuilderMode } from '../runtime/mode'
import { mergePatch } from '../runtime/object'
import { RESOURCE_FORM_BLOCK } from '../runtime/resource-form-panel'
import { useBuilder } from '../runtime/session'
import type { OptionSchema } from '../runtime/types'
import {
	type RenderedOption,
	type RenderedOptIn,
	type RenderedGroup,
	SEARCH_BAR_BLOCK,
	type InspectorTab,
	TAB_LABELS,
	PANELS,
	withSeparators,
	entriesOf,
	isOptIn,
	groupIcon,
	STYLE_GROUPS,
	PANEL_STYLE_SECTIONS,
} from '../build/Config'

const builder = useBuilder()
const session = builder.session

const path = computed(() => session.value.selection)
const block = builder.selected
const descriptor = builder.selectedDescriptor
const showAdvanced = ref(false)
// Advanced settings remain separate; lock explanations are visible in both modes.
const { advanced: advancedMode } = useBuilderMode()
// The engine words a reason as a lower-case fragment; here it opens a sentence.
const opaqueReason = computed(() => {
	const reason = block.value?.opaqueReason
	return reason
		? `${reason.charAt(0).toUpperCase()}${reason.slice(1)}.`
		: undefined
})

function parentType(parent: string): string | undefined {
	const draft = session.value.draft
	if (!draft) return undefined
	let list = draft.blocks
	let type: string | undefined
	for (const part of parent.split('/')) {
		const node = list.find((entry) => entry.name === part)
		if (!node) return undefined
		type = node.type
		list = node.children ?? []
	}
	return type
}

const parentDescriptor = computed(() => {
	const parent = path.value ? parentPath(path.value) : null
	return parent ? descriptorOf(session.value.catalog, parentType(parent)) : undefined
})
const parentBlock = computed(() => {
	const parent = path.value ? parentPath(path.value) : null
	return parent && session.value.draft
		? findNode(session.value.draft, parent)
		: undefined
})

const panel = computed(() =>
	advancedMode.value || block.value?.lockedOptions ? undefined : PANELS[block.value?.type ?? ''],
)

/** Whether a block's own panel edits this option rather than the list below. */
function inPanel(key: unknown): boolean {
	return panel.value?.options.has(String(key)) === true
}

// What a block's panel edits, it says is missing in its own words.
const missing = computed(() =>
	block.value
		? missingSettings(descriptor.value, block.value)
				.filter((entry) => !inPanel(entry.path[0]))
				.filter((entry) => !Object.hasOwn(block.value?.lockedOptions ?? {}, String(entry.path[0])))
				.map((entry) => entry.label)
		: [],
)
const childMeta = computed(() => parentDescriptor.value?.childMeta ?? {})

/**
 * The row of a section the block sits in, which the editor wrote around it: its
 * label, help text and layout are set here, as the block's own.
 */
const row = computed(() => {
	const parent = path.value ? parentPath(path.value) : null
	if (!parent || parentBlock.value?.type !== FIELD_ROW) {
		return undefined
	}
	const schema = parentDescriptor.value?.config ?? {}
	return {
		path: parent,
		config: parentBlock.value.config ?? {},
		options: Object.entries(schema)
			.filter(([, option]) => offeredIn(option, advancedMode.value))
			.map(([key, option]) => ({ key, schema: option })),
	}
})
const slots = computed(() => slotsOf(parentDescriptor.value, parentBlock.value))
const regionLabel = computed(() =>
	parentDescriptor.value?.label
		? `Inside ${parentDescriptor.value.label}`
		: 'Where it shows',
)

function config(): Record<string, unknown> {
	return block.value?.config ?? {}
}

function patch(key: string, value: unknown): void {
	if (path.value) {
		builder.patchConfig(path.value, { [key]: value })
	}
}

/**
 * An option marked `flatten` contributes its own properties to the group rather
 * than a nested editor, so a set of switches reads as one list of features.
 */
function expand(key: string, schema: OptionSchema): RenderedOption[] {
	if (!schema.ui?.flatten || !schema.properties) {
		return [
			{
				id: key,
				name: key,
				schema,
				value: config()[key],
				update: (value) => patch(key, value),
			},
		]
	}
	return Object.entries(schema.properties)
		.filter(([, nested]) => !nested.ui?.hidden)
		.sort(([, a], [, b]) => (a.ui?.order ?? 0) - (b.ui?.order ?? 0))
		.map(([nestedKey, nested]) => ({
			id: `${key}.${nestedKey}`,
			name: nestedKey,
			schema: nested,
			value: (config()[key] as Record<string, unknown> | undefined)?.[nestedKey],
			update: (value: unknown) =>
				patch(
					key,
					mergePatch(
						(config()[key] as Record<string, unknown>) ?? {},
						{ [nestedKey]: value },
					),
				),
		}))
}

const groups = computed<RenderedGroup[]>(() =>
	optionGroups(descriptor.value)
		.map((group) => ({
			id: group.id,
			label: group.label,
			options: withSeparators(
				group.options
					.filter((option) => !Object.hasOwn(block.value?.lockedOptions ?? {}, option.key))
					.flatMap((option) => expand(option.key, option.schema))
					// What the simple mode writes itself — a key from the label it
					// follows, an address from the table picked — or leaves to code.
					.filter(
						(option) =>
							offeredIn(option.schema, advancedMode.value) &&
							!inPanel(option.id.split('.')[0]),
					),
			),
		}))
		.filter((group) => group.options.length > 0),
)

/**
 * The switches turned on and not yet filled in, by block and label: an author
 * who turns one on and clears what it seeded is still looking at the options.
 */
const openedOptIns = ref(new Set<string>())

function optInKey(entry: RenderedOptIn): string {
	return `${path.value ?? ''}\u0000${entry.optIn}`
}

/** On while any option behind it is set, or while the author has it open. */
function optInOn(entry: RenderedOptIn): boolean {
	return (
		openedOptIns.value.has(optInKey(entry)) ||
		entry.options.some((option) => option.value !== undefined)
	)
}

/**
 * Turned on, the options start from what they suggest — the block's own
 * wording — rather than from nothing. Turned off, they are dropped, and the
 * block falls back on what it says by itself. One edit either way.
 */
function setOptIn(entry: RenderedOptIn, on: boolean): void {
	const opened = new Set(openedOptIns.value)
	if (on) {
		opened.add(optInKey(entry))
	} else {
		opened.delete(optInKey(entry))
	}
	openedOptIns.value = opened
	if (!path.value) {
		return
	}
	const values: Record<string, unknown> = {}
	for (const option of entry.options) {
		values[option.id] = on
			? (option.value ?? option.schema.ui?.placeholder)
			: undefined
	}
	builder.patchConfig(path.value, values)
}

const plainGroups = computed(() =>
	groups.value.filter((group) => group.id !== ADVANCED_OPTION_GROUP),
)
const advanced = computed(() =>
	advancedMode.value
		? groups.value.find((group) => group.id === ADVANCED_OPTION_GROUP)
		: undefined,
)

function tabOfGroup(id: string): InspectorTab {
	if (STYLE_GROUPS.has(id)) {
		return 'style'
	}
	if (id === 'data' && tabs.value.includes('data')) {
		return 'data'
	}
	return tabs.value[0] ?? 'content'
}

/** The tabs this block has, those with nothing in them left out. */
const tabs = computed<InspectorTab[]>(() => {
	if (panel.value) {
		return panel.value.tabs.filter(
			(tab) =>
				tab !== 'style' ||
				plainGroups.value.some((group) => STYLE_GROUPS.has(group.id)) ||
				slots.value.length > 0 ||
				Object.keys(childMeta.value).length > 0 ||
				PANEL_STYLE_SECTIONS.has(block.value?.type ?? ''),
		)
	}
	const filled = new Set<InspectorTab>(['content'])
	for (const group of plainGroups.value) {
		filled.add(STYLE_GROUPS.has(group.id) ? 'style' : group.id === 'data' ? 'data' : 'content')
	}
	if (descriptor.value?.controllerArg) {
		filled.add('data')
	}
	if (slots.value.length || Object.keys(childMeta.value).length) {
		filled.add('style')
	}
	return (['content', 'data', 'style'] as InspectorTab[]).filter((tab) => filled.has(tab))
})

const chosenTab = ref<InspectorTab>('content')
// Another block opens on its first tab.
watch(path, () => {
	chosenTab.value = tabs.value[0] ?? 'content'
})
/** The tab on show: the one picked, or the first when this block has no such tab. */
const tab = computed<InspectorTab>(() =>
	tabs.value.includes(chosenTab.value) ? chosenTab.value : (tabs.value[0] ?? 'content'),
)

/* ---- what lives on the resource rather than on the block ---------------- */

const resource = computed(() =>
	block.value?.controller
		? session.value.resourceStructures[block.value.controller]
		: undefined,
)
const fieldCount = computed(() => resource.value?.fields.length ?? 0)
/** What the fields of the table are, to the block reading it. */
const fieldsHint = computed(() =>
	block.value?.type === RESOURCE_FORM_BLOCK
		? "The form asks for the table's fields, in the table's order."
		: 'What each column shows, and how rows are searched, sorted and filtered.',
)
const searchField = computed(
	() => resource.value?.fields.find((field) => field.searchable)?.name,
)

watch(
	() => block.value?.controller,
	(ref) => {
		if (ref) void builder.loadResource(ref)
	},
	{ immediate: true },
)

/** One searchable field at a time here; the DMS itself allows several. */
async function setSearchField(name: string): Promise<void> {
	const current = resource.value
	if (!current || !block.value?.controller) {
		return
	}
	for (const field of current.fields) {
		const wanted = field.name === name
		if (!!field.searchable !== wanted) {
			await builder.configureField(
				`${block.value.controller}#${field.name}`,
				{ searchable: wanted },
			)
		}
	}
}
</script>

<template>
	<div v-if="!block || !path" class="text-sm text-dimmed">
		Select a block on the page to configure it.
	</div>

	<div v-else class="flex flex-col gap-3">
		<!-- The block's settings by what they are about; the tabs stay where
		they are from block to block, the first one open on each. -->
		<nav
			v-if="tabs.length > 1 && !block.preserve"
			role="tablist"
			aria-label="Settings"
			class="-mx-4 -mt-4 mb-1 flex gap-0.5 border-b border-default px-2"
		>
			<button
				v-for="entry in tabs"
				:key="entry"
				type="button"
				role="tab"
				:aria-selected="tab === entry"
				class="relative inline-flex h-9 items-center px-2 text-[12.5px] hover:text-highlighted"
				:class="
					tab === entry
						? 'font-semibold text-highlighted after:absolute after:inset-x-2 after:-bottom-px after:h-0.5 after:rounded-t-sm after:bg-primary'
						: 'font-medium text-muted'
				"
				@click="chosenTab = entry"
			>
				{{ TAB_LABELS[entry] }}
			</button>
		</nav>

		<div
			v-if="block.preserve"
			class="flex flex-col gap-2 rounded-md border border-default bg-elevated p-3 text-sm text-dimmed"
		>
			<p>
				This block is set up in code, so its settings can't be changed here.
			</p>
			<p class="text-xs">
				<span v-if="opaqueReason">{{ opaqueReason }} </span>
				Edit it in
				<code class="text-xs">{{ session.structure?.page.filepath }}</code>.
			</p>
		</div>

		<template v-else>
			<div v-if="block.lockedOptions" class="rounded-md border border-default bg-elevated p-3 text-sm" role="note">
				<p class="font-medium">Some options are managed in code</p>
				<p class="text-xs text-muted">You can edit the other options. Locked expressions stay unchanged on save. The block type, controller and child placement stay fixed.</p>
				<p class="text-xs text-muted">The preview keeps the running version until these changes are saved.</p>
				<ul class="mt-2 space-y-1 text-xs">
					<li v-for="(reason, key) in block.lockedOptions" :key="key"><strong>{{ key }}</strong>: {{ reason }}</li>
				</ul>
			</div>
			<div
				v-if="missing.length"
				class="flex flex-col gap-1 rounded-md border border-warning bg-warning/10 p-3 text-xs text-warning"
			>
				<span class="font-medium">Still to fill in</span>
				<ul class="flex flex-col gap-0.5">
					<li v-for="entry in missing" :key="entry">{{ entry }}</li>
				</ul>
			</div>

			<section
				v-if="descriptor?.controllerArg && !inPanel(CONTROLLER_SETTING) && !block.lockedOptions"
				v-show="tab === tabOfGroup('data')"
				:class="PANEL_CARD"
				aria-label="Table"
			>
				<p class="flex items-center gap-2 text-sm font-semibold text-highlighted">
					<UIcon name="i-ph-table-light" class="size-4 text-primary" />
					Table
				</p>
				<div class="flex flex-col gap-1.5">
					<label class="text-sm text-muted">Database table</label>
					<USelectMenu
						:model-value="block.controller"
						:items="
							session.resources.map((entry) => ({
								label: entry.ref,
								value: entry.ref,
							}))
						"
						value-key="value"
						placeholder="Choose a table…"
						@update:model-value="builder.setController(path, $event)"
					/>
					<p class="text-[13px]/[18px] text-muted">
						This block reads and writes this table.
					</p>
				</div>
				<UButton
					color="neutral"
					variant="outline"
					block
					:disabled="!block.controller"
					trailing-icon="i-ph-caret-right-light"
					icon="i-ph-list-light"
					:label="
						block.controller
							? `Edit the table's ${fieldCount} field${fieldCount === 1 ? '' : 's'}`
							: 'Choose a table first'
					"
					@click="builder.setView('resource')"
				/>
				<p class="flex gap-2 rounded-md bg-warning/10 px-2.5 py-2 text-xs text-warning">
					<UIcon name="i-ph-info-light" class="mt-px size-3.5 shrink-0" />
					<span>
						{{ fieldsHint }} Changing them changes the table itself, on every page
						using it, right away — not on Save.
					</span>
				</p>

				<div
					v-if="block.type === SEARCH_BAR_BLOCK"
					class="flex flex-col gap-1.5"
				>
					<label class="text-sm text-muted">Search field</label>
					<USelectMenu
						:model-value="searchField"
						:items="
							(resource?.fields ?? []).map((field) => ({
								label: field.name,
								value: field.name,
							}))
						"
						value-key="value"
						:disabled="!resource"
						placeholder="— None —"
						@update:model-value="setSearchField($event)"
					/>
					<p class="text-[13px]/[18px] text-muted">
						Used by the table's search bar. The DMS accepts several; this
						picker sets one.
					</p>
				</div>
			</section>

			<section
				v-if="row"
				v-show="tab === (tabs[0] ?? 'content')"
				:class="PANEL_CARD"
				aria-label="Its row"
			>
				<p class="flex items-center gap-2 text-sm font-semibold text-highlighted">
					<UIcon name="i-ph-text-columns-light" class="size-4 text-primary" />
					Its row in the section
				</p>
				<DmsBuilderOption
					v-for="option in row.options"
					:key="option.key"
					:name="option.key"
					:schema="option.schema"
					:model-value="row.config[option.key]"
					@update:model-value="builder.patchConfig(row.path, { [option.key]: $event })"
				/>
			</section>

			<component :is="panel.component" v-if="panel" :key="path" :path="path" :tab="tab" />

			<section
				v-for="group in plainGroups"
				v-show="tabOfGroup(group.id) === tab"
				:key="group.id"
				:class="PANEL_CARD"
				:aria-label="group.label"
			>
				<p class="flex items-center gap-2 text-sm font-semibold text-highlighted">
					<UIcon :name="groupIcon(group.id)" class="size-4 text-primary" />
					{{ group.label }}
				</p>
				<template v-for="entry in entriesOf(group.options)" :key="entry.id">
					<div v-if="isOptIn(entry)" class="flex flex-col gap-3">
						<div class="flex items-center gap-3">
							<USwitch
								:model-value="optInOn(entry)"
								:aria-label="entry.optIn"
								@update:model-value="setOptIn(entry, $event === true)"
							/>
							<span class="text-sm text-default">{{ entry.optIn }}</span>
						</div>
						<div
							v-if="optInOn(entry)"
							class="flex flex-col gap-3 border-l border-default pl-3"
						>
							<DmsBuilderOption
								v-for="option in entry.options"
								:key="option.id"
								:name="option.name"
								:schema="option.schema"
								:model-value="option.value"
								:resource="block.controller"
								:block-name="block.name"
								@update:model-value="option.update($event)"
								@patch="builder.patchConfig(path, $event)"
							/>
						</div>
					</div>
					<DmsBuilderOption
						v-else
						:name="entry.name"
						:schema="entry.schema"
						:model-value="entry.value"
						:resource="block.controller"
						:block-name="block.name"
						:separated="entry.separated"
						@update:model-value="entry.update($event)"
						@patch="builder.patchConfig(path, $event)"
					/>
				</template>
			</section>

			<DmsBuilderGuardSettings
				v-if="GUARDED_BLOCKS.has(block.type ?? '')"
				v-show="tab === (tabs[0] ?? 'content')"
				:path="path"
			/>

			<!-- A block dropped in lands in the region on screen; this is how it is
			moved to another one afterwards. Named after the container rather than
			called a slot, which is a word the gesture exists to spare anyone. -->
			<section
				v-if="slots.length"
				v-show="tab === 'style'"
				:class="PANEL_CARD"
				:aria-label="regionLabel"
			>
				<label class="flex items-center gap-2 text-sm font-semibold text-highlighted">
					<UIcon name="i-ph-squares-four-light" class="size-4 text-primary" />
					{{ regionLabel }}
				</label>
				<USelectMenu
					:model-value="block.slot"
					:items="slots.map((slot) => ({ label: slot.label, value: slot.id }))"
					value-key="value"
					placeholder="Choose where it shows…"
					@update:model-value="builder.setSlot(path, $event)"
				/>
			</section>

			<section
				v-if="Object.keys(childMeta).length"
				v-show="tab === 'style'"
				:class="PANEL_CARD"
				aria-label="Placement"
			>
				<p class="flex items-center gap-2 text-sm font-semibold text-highlighted">
					<UIcon name="i-ph-arrows-out-cardinal-light" class="size-4 text-primary" />
					Placement
				</p>
				<DmsBuilderOption
					v-for="[key, schema] in Object.entries(childMeta)"
					:key="key"
					:name="key"
					:schema="schema"
					:model-value="(block.meta ?? {})[key]"
					@update:model-value="builder.patchMeta(path, { [key]: $event })"
				/>
			</section>

			<section
				v-if="advanced"
				v-show="tab === (tabs[0] ?? 'content')"
				:class="PANEL_CARD"
				aria-label="Advanced"
			>
				<button
					type="button"
					class="flex w-full items-center gap-2 text-sm font-semibold text-highlighted"
					:aria-expanded="showAdvanced"
					@click="showAdvanced = !showAdvanced"
				>
					<UIcon name="i-ph-code-light" class="size-4 text-primary" />
					Advanced
					<span class="ml-auto text-[13px] font-normal text-muted">
						{{ advanced.options.length }}
					</span>
					<UIcon
						:name="showAdvanced ? 'i-ph-caret-up' : 'i-ph-caret-down'"
						class="size-4 text-dimmed"
					/>
				</button>
				<div v-if="showAdvanced" class="flex flex-col gap-3">
					<DmsBuilderOption
						v-for="option in advanced.options"
						:key="option.id"
						:name="option.name"
						:schema="option.schema"
						:model-value="option.value"
						:resource="block.controller"
						@update:model-value="option.update($event)"
					/>
				</div>
			</section>
		</template>
	</div>
</template>
