import { expect } from "chai";
import { DEFAULT_ROOT_ACL } from "../../../acl/defaults";
import { serializeAcl } from "../../../acl/entries";
import {
  type AclActor,
  resolveFolderAccess,
  resolveRootRights,
} from "../../../acl/resolver";
import { MEDIA_PAGE_PERMISSION } from "../../../pages/files";
import type { MediaFolder } from "../../../db/tables";
import type { AclEntry } from "../../../types";

interface FolderSeed {
  id: string;
  parentId?: string;
  acl?: AclEntry[];
  rawAcl?: string;
}

function buildFolder(seed: FolderSeed): MediaFolder {
  return {
    _id: seed.id,
    name: seed.id,
    parentId: seed.parentId,
    path: [],
    json_acl: seed.rawAcl ?? serializeAcl(seed.acl),
    visibility: "private",
    createdAt: new Date(),
    updatedAt: new Date(),
  };
}

function buildActor(permissions: string[], roleIds: string[] = []): AclActor {
  return { permissions: new Set(permissions), roleIds };
}

/** The ids `acl` names as subjects of `kind`: an actor holding them all is matched by every entry. */
function subjectIds(
  acl: readonly AclEntry[],
  kind: AclEntry["subject"]["kind"],
): string[] {
  return acl
    .filter((entry) => entry.subject.kind === kind)
    .map((entry) => entry.subject.id);
}

const EDIT_ARTICLES_PERMISSION = "articles.table.edit";
const LIBRARY_VIEW_PERMISSION = "library.view";
const LIBRARY_UPLOAD_PERMISSION = "library.upload";
const LIBRARY_MANAGE_PERMISSION = "library.manage";

const libraryRootAcl: AclEntry[] = [
  {
    subject: { kind: "permission", id: LIBRARY_VIEW_PERMISSION },
    rights: ["read"],
  },
  {
    subject: { kind: "permission", id: LIBRARY_UPLOAD_PERMISSION },
    rights: ["write"],
  },
  {
    subject: { kind: "permission", id: LIBRARY_MANAGE_PERMISSION },
    rights: ["manage"],
  },
];

const editorsRoleAcl: AclEntry[] = [
  { subject: { kind: "role", id: "editors" }, rights: ["write"] },
];

const articlesPermissionAcl: AclEntry[] = [
  {
    subject: { kind: "permission", id: EDIT_ARTICLES_PERMISSION },
    rights: ["write"],
  },
];

describe("[unit] acl/resolver — resolveFolderAccess", () => {
  it("grants everything everywhere to the owner wildcard", () => {
    const folders = [
      buildFolder({ id: "a" }),
      buildFolder({ id: "b", parentId: "a", acl: [] }),
    ];
    const access = resolveFolderAccess(folders, buildActor(["*"]), []);
    expect([...access.manageable].sort()).to.deep.equal(["a", "b"]);
    expect([...access.readable].sort()).to.deep.equal(["a", "b"]);
    expect(access.shells.size).to.equal(0);
  });

  it("applies the root ACL to folders without their own ACL", () => {
    const folders = [buildFolder({ id: "root" })];
    const reader = resolveFolderAccess(
      folders,
      buildActor([LIBRARY_VIEW_PERMISSION]),
      libraryRootAcl,
    );
    expect(reader.readable.has("root")).to.equal(true);
    expect(reader.writable.has("root")).to.equal(false);
    expect(reader.manageable.has("root")).to.equal(false);
  });

  it("expands right implications (write ⇒ read, manage ⇒ write+read)", () => {
    const folders = [buildFolder({ id: "root" })];
    const uploader = resolveFolderAccess(
      folders,
      buildActor([LIBRARY_UPLOAD_PERMISSION]),
      libraryRootAcl,
    );
    expect(uploader.readable.has("root")).to.equal(true);
    expect(uploader.writable.has("root")).to.equal(true);
    expect(uploader.manageable.has("root")).to.equal(false);

    const manager = resolveFolderAccess(
      folders,
      buildActor([LIBRARY_MANAGE_PERMISSION]),
      libraryRootAcl,
    );
    expect(manager.readable.has("root")).to.equal(true);
    expect(manager.writable.has("root")).to.equal(true);
    expect(manager.manageable.has("root")).to.equal(true);
  });

  it("propagates the parent's effective rights when a child has no ACL", () => {
    const folders = [
      buildFolder({ id: "parent", acl: editorsRoleAcl }),
      buildFolder({ id: "child", parentId: "parent" }),
      buildFolder({ id: "grandchild", parentId: "child" }),
    ];
    const editor = resolveFolderAccess(
      folders,
      buildActor([], ["editors"]),
      [],
    );
    expect(editor.writable.has("child")).to.equal(true);
    expect(editor.writable.has("grandchild")).to.equal(true);
  });

  it("lets a folder ACL fully override the inherited one", () => {
    const restrictedAcl: AclEntry[] = [
      { subject: { kind: "role", id: "admins" }, rights: ["manage"] },
    ];
    const folders = [
      buildFolder({ id: "parent", acl: editorsRoleAcl }),
      buildFolder({ id: "child", parentId: "parent", acl: restrictedAcl }),
    ];
    const editor = resolveFolderAccess(
      folders,
      buildActor([], ["editors"]),
      [],
    );
    expect(editor.writable.has("parent")).to.equal(true);
    expect(editor.readable.has("child")).to.equal(false);

    const admin = resolveFolderAccess(folders, buildActor([], ["admins"]), []);
    expect(admin.readable.has("parent")).to.equal(false);
    expect(admin.manageable.has("child")).to.equal(true);
  });

  it("matches permission subjects against the actor's effective permission set", () => {
    const folders = [
      buildFolder({ id: "articles-assets", acl: articlesPermissionAcl }),
    ];
    const magasinier = resolveFolderAccess(
      folders,
      buildActor([EDIT_ARTICLES_PERMISSION]),
      [],
    );
    expect(magasinier.writable.has("articles-assets")).to.equal(true);

    const outsider = resolveFolderAccess(
      folders,
      buildActor([MEDIA_PAGE_PERMISSION]),
      [],
    );
    expect(outsider.readable.has("articles-assets")).to.equal(false);
  });

  it("returns non-readable ancestors of readable folders as shells", () => {
    const folders = [
      buildFolder({ id: "top", acl: [] }),
      buildFolder({ id: "middle", parentId: "top" }),
      buildFolder({ id: "leaf", parentId: "middle", acl: editorsRoleAcl }),
    ];
    const editor = resolveFolderAccess(
      folders,
      buildActor([], ["editors"]),
      [],
    );
    expect(editor.readable.has("leaf")).to.equal(true);
    expect(editor.readable.has("top")).to.equal(false);
    expect(editor.readable.has("middle")).to.equal(false);
    expect([...editor.shells].sort()).to.deep.equal(["middle", "top"]);
  });

  it("keeps unreadable folders out of every set", () => {
    const folders = [
      buildFolder({ id: "hidden", acl: [] }),
      buildFolder({ id: "hidden-child", parentId: "hidden" }),
    ];
    const actor = resolveFolderAccess(
      folders,
      buildActor([MEDIA_PAGE_PERMISSION]),
      [],
    );
    expect(actor.readable.size).to.equal(0);
    expect(actor.writable.size).to.equal(0);
    expect(actor.manageable.size).to.equal(0);
    expect(actor.shells.size).to.equal(0);
  });

  it("grants no rights to folders whose parent is missing", () => {
    const folders = [
      buildFolder({ id: "orphan", parentId: "gone" }),
      buildFolder({ id: "orphan-child", parentId: "orphan" }),
    ];
    const reader = resolveFolderAccess(
      folders,
      buildActor([LIBRARY_VIEW_PERMISSION, LIBRARY_MANAGE_PERMISSION]),
      libraryRootAcl,
    );
    expect(reader.readable.size).to.equal(0);
    expect(reader.writable.size).to.equal(0);
    expect(reader.manageable.size).to.equal(0);
    expect(reader.shells.size).to.equal(0);
  });

  it("grants members nothing at the root by default", () => {
    const folders = [buildFolder({ id: "root" })];
    const actor = buildActor([MEDIA_PAGE_PERMISSION]);
    expect(resolveRootRights(actor, DEFAULT_ROOT_ACL).size).to.equal(0);
    const named = buildActor(
      subjectIds(DEFAULT_ROOT_ACL, "permission"),
      subjectIds(DEFAULT_ROOT_ACL, "role"),
    );
    expect(resolveRootRights(named, DEFAULT_ROOT_ACL).size).to.equal(0);
    const access = resolveFolderAccess(folders, actor, DEFAULT_ROOT_ACL);
    expect(access.readable.size).to.equal(0);
    const owner = resolveFolderAccess(
      folders,
      buildActor(["*"]),
      DEFAULT_ROOT_ACL,
    );
    expect(owner.manageable.has("root")).to.equal(true);
  });

  it("grants every root right to the owner wildcard", () => {
    const rights = resolveRootRights(buildActor(["*"]), []);
    expect(rights.has("read")).to.equal(true);
    expect(rights.has("write")).to.equal(true);
    expect(rights.has("manage")).to.equal(true);
  });

  it("matches any permission subject for the owner wildcard", () => {
    const folders = [
      buildFolder({ id: "articles-assets", acl: articlesPermissionAcl }),
    ];
    const owner = resolveFolderAccess(folders, buildActor(["*"]), []);
    expect(owner.manageable.has("articles-assets")).to.equal(true);
  });

  it("resolves root rights from the root ACL for regular actors", () => {
    const rights = resolveRootRights(
      buildActor([LIBRARY_UPLOAD_PERMISSION]),
      libraryRootAcl,
    );
    expect(rights.has("write")).to.equal(true);
    expect(rights.has("manage")).to.equal(false);
  });

  it("fails closed instead of inheriting when a stored ACL is malformed", () => {
    const folders = [
      buildFolder({ id: "root", acl: editorsRoleAcl }),
      buildFolder({ id: "broken", parentId: "root", rawAcl: "{not json" }),
    ];
    const editor = resolveFolderAccess(
      folders,
      buildActor([], ["editors"]),
      [],
    );
    expect(editor.writable.has("root")).to.equal(true);
    expect(editor.readable.has("broken")).to.equal(false);
  });

  it("locks down a child with an explicit empty ACL under a permissive parent", () => {
    const folders = [
      buildFolder({ id: "open", acl: editorsRoleAcl }),
      buildFolder({ id: "locked", parentId: "open", acl: [] }),
    ];
    const editor = resolveFolderAccess(
      folders,
      buildActor([], ["editors"]),
      [],
    );
    expect(editor.writable.has("open")).to.equal(true);
    expect(editor.readable.has("locked")).to.equal(false);
    expect(editor.shells.has("locked")).to.equal(false);
  });

  it("ignores unknown rights and unknown subject kinds", () => {
    const exoticAcl = JSON.stringify([
      { subject: { kind: "role", id: "editors" }, rights: ["teleport"] },
      { subject: { kind: "group", id: "editors" }, rights: ["manage"] },
    ]);
    const folders = [buildFolder({ id: "root", rawAcl: exoticAcl })];
    const editor = resolveFolderAccess(
      folders,
      buildActor([], ["editors"]),
      [],
    );
    expect(editor.readable.size).to.equal(0);
    expect(editor.writable.size).to.equal(0);
    expect(editor.manageable.size).to.equal(0);
  });

  it("stays finite and grants nothing on a parentId cycle", () => {
    const folders = [
      buildFolder({ id: "a", parentId: "b" }),
      buildFolder({ id: "b", parentId: "a" }),
      buildFolder({ id: "sane" }),
    ];
    const reader = resolveFolderAccess(
      folders,
      buildActor([LIBRARY_VIEW_PERMISSION]),
      libraryRootAcl,
    );
    expect(reader.readable.has("sane")).to.equal(true);
    expect(reader.readable.has("a")).to.equal(false);
    expect(reader.readable.has("b")).to.equal(false);
  });
});
