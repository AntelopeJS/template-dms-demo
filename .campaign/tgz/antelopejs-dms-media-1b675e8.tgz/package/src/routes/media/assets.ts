import { MediaApiController } from "./controller";
import {
  moveAsset,
  removeAsset,
  setAssetVisibility,
  updateAssetDetails,
} from "./asset-actions";
import {
  Delete,
  Get,
  JSONBody,
  Parameter,
  Post,
} from "@antelopejs/interface-api";
import { assert } from "@antelopejs/interface-api-util";
import { CreateReadUrl } from "@antelopejs/interface-file-storage";
import { getMediaConfig } from "../../config";
import { type MediaAsset, MediaAssetModel } from "../../db";
import { ensureDerivative } from "../../derivatives";
import { type MediaPresetConfig, SVG_MIMETYPE } from "../../presets";
import {
  assetVisibilitySchema,
  MEDIA_ERRORS,
  moveAssetSchema,
  parseBody,
  previewIdsSchema,
  updateAssetSchema,
} from "../../validation/media.schema";
import {
  PREVIEW_URL_TTL_SECONDS,
  PRIVATE_READ_URL_TTL_SECONDS,
} from "./constants";
import { type MediaRequestContext, requireFolderRight } from "./context";
import { assertDerivableAsset, requirePreset } from "./delivery";
import { buildAssetDto } from "./dto";

const HTTP_NOT_FOUND = 404;
const MAX_SEARCH_RESULTS = 100;
const MAX_LISTING_RESULTS = 1000;
const THUMB_PRESET_ID = "thumb";
const UNCROPPED_PRESET_ID = "preview";

/** The presets library thumbnails are rendered with: the square crop, and an uncropped size when configured. */
interface PreviewPresets {
  thumb: MediaPresetConfig;
  uncropped?: MediaPresetConfig;
}

/**
 * Vectors are mostly logos and icons, often far wider than tall: the square
 * crop of `thumb` cuts their ends off, so they get the uncropped `preview`
 * size, which the explorer fits inside the tile.
 */
function previewPresetOf(
  asset: MediaAsset,
  presets: PreviewPresets,
): MediaPresetConfig {
  const isVector = asset.mimetype === SVG_MIMETYPE;
  const isUncropped = presets.uncropped && presets.uncropped.fit !== "cover";
  return isVector && isUncropped && presets.uncropped
    ? presets.uncropped
    : presets.thumb;
}

async function buildPreviewEntry(
  context: MediaRequestContext,
  assetId: string,
  presets: PreviewPresets,
): Promise<[string, string] | null> {
  const asset = await context.assetModel.get(assetId);
  if (
    !asset ||
    asset.isDeleting ||
    !context.access.readable.has(asset.folderId)
  )
    return null;
  if (!asset.mimetype.startsWith("image/")) return null;
  const preset = previewPresetOf(asset, presets);
  try {
    const derivativeKey = await ensureDerivative(
      context.assetModel,
      asset,
      preset,
    );
    const readUrl = await CreateReadUrl(
      derivativeKey,
      PREVIEW_URL_TTL_SECONDS,
      asset.storage,
    );
    return [assetId, readUrl.url];
  } catch {
    return null;
  }
}

export async function requireReadableAsset(
  context: MediaRequestContext,
  assetId: string,
): Promise<MediaAsset> {
  const asset = await context.assetModel.get(assetId);
  assert(
    asset && !asset.isDeleting && context.access.readable.has(asset.folderId),
    HTTP_NOT_FOUND,
    MEDIA_ERRORS.assetNotFound,
  );
  return asset;
}

function matchesSearch(asset: MediaAsset, term: string, mime: string): boolean {
  if (asset.isDeleting) return false;
  const matchesTerm =
    term.length === 0 || asset.name.toLowerCase().includes(term);
  const matchesMime = mime.length === 0 || asset.mimetype.startsWith(mime);
  return matchesTerm && matchesMime;
}

export class MediaAssetsController extends MediaApiController {
  @Get("/assets")
  async listAll() {
    const context = await this.resolveContext();
    const readableFolders = [...context.access.readable];
    if (readableFolders.length === 0) return { assets: [], truncated: false };
    const candidates = await context.assetModel.listByFolders(
      readableFolders,
      MAX_LISTING_RESULTS + 1,
    );
    const truncated = candidates.length > MAX_LISTING_RESULTS;
    const assets = candidates
      .slice(0, MAX_LISTING_RESULTS)
      .map((asset) => buildAssetDto(context, asset));
    return { assets, truncated };
  }

  @Post("/previews")
  async previews(@JSONBody() body: unknown) {
    const { ids } = parseBody(body, previewIdsSchema);
    const context = await this.resolveContext();
    const { presets } = getMediaConfig();
    const thumb = presets.get(THUMB_PRESET_ID);
    if (!thumb) return { previews: {} };
    const previewPresets = {
      thumb,
      uncropped: presets.get(UNCROPPED_PRESET_ID),
    };
    const entries = await Promise.all(
      ids.map((id) => buildPreviewEntry(context, id, previewPresets)),
    );
    const previews = Object.fromEntries(
      entries.filter((entry): entry is [string, string] => entry !== null),
    );
    return { previews };
  }

  @Get("/assets/search")
  async search(
    @Parameter("q", "query") q?: string,
    @Parameter("mime", "query") mime?: string,
    @Parameter("folderId", "query") folderId?: string,
  ) {
    const context = await this.resolveContext();
    const searchedFolders = folderId
      ? [requireFolderRight(context, folderId, "read")._id]
      : [...context.access.readable];
    if (searchedFolders.length === 0) return { assets: [] };
    const candidates = context.assetModel.table.getAll(
      searchedFolders.length === 1 ? searchedFolders[0] : searchedFolders,
      "folderId",
    );
    const term = (q ?? "").trim().toLowerCase();
    const mimePrefix = (mime ?? "").trim().toLowerCase();
    const assets: ReturnType<typeof buildAssetDto>[] = [];
    for await (const row of candidates) {
      const asset = MediaAssetModel.fromDatabase(row);
      if (!asset || !matchesSearch(asset, term, mimePrefix)) continue;
      assets.push(buildAssetDto(context, asset));
      if (assets.length === MAX_SEARCH_RESULTS) break;
    }
    return { assets };
  }

  @Get("/assets/:assetId")
  async getAsset(@Parameter("assetId", "param") assetId: string) {
    const context = await this.resolveContext();
    const asset = await requireReadableAsset(context, assetId);
    return { asset: buildAssetDto(context, asset) };
  }

  @Get("/assets/:assetId/read-url")
  async readUrl(
    @Parameter("assetId", "param") assetId: string,
    @Parameter("preset", "query") presetId?: string,
  ) {
    const context = await this.resolveContext();
    const asset = await requireReadableAsset(context, assetId);
    let storageKey = asset.storageKey;
    if (presetId) {
      const preset = requirePreset(presetId);
      assertDerivableAsset(asset);
      storageKey = await ensureDerivative(context.assetModel, asset, preset);
    }
    const readUrl = await CreateReadUrl(
      storageKey,
      PRIVATE_READ_URL_TTL_SECONDS,
      asset.storage,
    );
    return { url: readUrl.url, expiresAt: readUrl.expiresAt };
  }

  @Post("/assets/:assetId/update")
  async updateAsset(
    @Parameter("assetId", "param") assetId: string,
    @JSONBody() body: unknown,
  ) {
    const changes = parseBody(body, updateAssetSchema);
    const context = await this.resolveContext();
    const asset = await requireReadableAsset(context, assetId);
    await updateAssetDetails(context, asset, changes);
    return { ok: true };
  }

  @Post("/assets/:assetId/move")
  async moveAsset(
    @Parameter("assetId", "param") assetId: string,
    @JSONBody() body: unknown,
  ) {
    const { folderId } = parseBody(body, moveAssetSchema);
    const context = await this.resolveContext();
    const asset = await requireReadableAsset(context, assetId);
    await moveAsset(context, asset, folderId);
    return { ok: true };
  }

  @Post("/assets/:assetId/visibility")
  async setVisibility(
    @Parameter("assetId", "param") assetId: string,
    @JSONBody() body: unknown,
  ) {
    const { visibility } = parseBody(body, assetVisibilitySchema);
    const context = await this.resolveContext();
    const asset = await requireReadableAsset(context, assetId);
    await setAssetVisibility(context, asset, visibility);
    return { ok: true };
  }

  @Delete("/assets/:assetId")
  async deleteAsset(@Parameter("assetId", "param") assetId: string) {
    const context = await this.resolveContext();
    const asset = await requireReadableAsset(context, assetId);
    await removeAsset(context, asset);
    return { ok: true };
  }
}
