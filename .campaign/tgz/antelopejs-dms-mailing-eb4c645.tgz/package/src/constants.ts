export const MODULE_ID = "mailing";
export const API_BASE_PATH = "/api/mailing";
export const TABLES_BASE_PATH = `${API_BASE_PATH}/tables`;
export const MODULE_BASE_PATH = `/modules/${MODULE_ID}`;
export const TEMPLATES_PATH = `${MODULE_BASE_PATH}/templates`;
export const SENDS_PATH = `${MODULE_BASE_PATH}/sends`;
export const SETTINGS_PATH = `${MODULE_BASE_PATH}/settings`;
export const NEW_TEMPLATE_BUTTON_ID = "create";
export const NEW_TEMPLATE_ACTION_ID = "mailing.new-template";
export const FRONTEND_MODULE_NAME = "@antelopejs/dms-mailing-frontend-vue";
/** The header a provider webhook carries the secret its route checks in. */
export const WEBHOOK_SECRET_HEADER = "x-mailing-webhook-secret";
export const EMAIL_TEMPLATE_NAME = "EmailMailingTemplate";

export const MAILING_SEND_PERMISSION = "mailing.send";

export const OVERVIEW_PERIOD_SCOPE = "mailing-overview";
export const SENDS_PERIOD_SCOPE = "mailing-sends";

export const MAILING_SENDS_TOPIC = "mailing:sends";

export const GALLERY_DISPLAY_ID = `${MODULE_ID}:gallery`;
export const TEMPLATE_CATEGORIES_TYPE_ID = "mailing_template_categories";
export const TEMPLATE_CATEGORY_TYPE_ID = "mailing_template_category";

export const MAX_SLUG_LENGTH = 64;
export const MAX_NAME_LENGTH = 120;
export const SLUG_PATTERN = /^[a-z0-9][a-z0-9-]*$/;

export const HTTP_BAD_REQUEST = 400;
export const HTTP_FORBIDDEN = 403;
export const HTTP_NOT_FOUND = 404;
export const HTTP_CONFLICT = 409;
export const HTTP_UNPROCESSABLE = 422;

export const LOCALE_LIST_SEPARATOR = ",";

/** The status of a template taken out of use. */
export const ARCHIVED_STATUS = "archived";

export const UNSUBSCRIBE_URL_PATH = "unsubscribeUrl";
export const PREFERENCES_URL_PATH = "preferencesUrl";

/** The URLs a caller passes for the footer links, not declared by hand. */
export const SYSTEM_VARIABLE_PATHS = [
  UNSUBSCRIBE_URL_PATH,
  PREFERENCES_URL_PATH,
];

/**
 * Ceiling on a metrics window. `from`/`to` are plain query parameters, and the
 * daily series allocates one bucket per day, so an unbounded window lets a
 * caller size the response by hand.
 */
export const MAX_WINDOW_DAYS = 400;
