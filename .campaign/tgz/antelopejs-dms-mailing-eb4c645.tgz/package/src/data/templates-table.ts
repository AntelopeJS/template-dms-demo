import {
  Controller,
  HTTPResult,
  Parameter,
  type RequestContext,
} from "@antelopejs/interface-api";
import { assert, assertValidation } from "@antelopejs/interface-api-util";
import { z } from "zod";
import {
  DataController,
  type DataControllerCallback,
  RegisterDataController,
} from "@antelopejs/interface-data-api";
import type {
  Parameters,
  Validation,
} from "@antelopejs/interface-data-api/components";
import {
  Access,
  AccessMode,
  Filter,
  type FilterFunction,
  Listable,
  Mandatory,
  ModelReference,
  ModifierKey,
  Sortable,
} from "@antelopejs/interface-data-api/metadata";
import {
  GetModel,
  LocalizationModifier,
} from "@antelopejs/interface-database-decorators";
import {
  LOCALIZED_TEXT_FALLBACK_LOCALE,
  type LocalizedText,
} from "@antelopejs/interface-dms-mailing";
import { authenticateTenantRequest } from "@antelopejs/interface-dms/guards";
import { getRequestTenantId } from "@antelopejs/interface-dms/request-tenant";
import { TenantScopedModel } from "@antelopejs/interface-dms/tenant-scoped-model";
import {
  Column,
  Exported,
  Searchable,
  Select,
  TableViewRoutes,
} from "@antelopejs/interface-dms/base";
import { DefaultDataTypes } from "@antelopejs/interface-dms/base/data-types/default-types";
import { DefaultDisplays } from "@antelopejs/interface-dms/base/table-view";
import { ReadonlyBehaviorType } from "@antelopejs/interface-dms/base/types";
import {
  ARCHIVED_STATUS,
  HTTP_BAD_REQUEST,
  HTTP_CONFLICT,
  HTTP_NOT_FOUND,
  HTTP_UNPROCESSABLE,
  MAX_NAME_LENGTH,
  MAX_SLUG_LENGTH,
  TABLES_BASE_PATH,
} from "../constants";
import { TemplateCategoryType } from "../data-types";
import { footerForCategory } from "../engine";
import {
  MailingTemplate,
  SendModel,
  type TemplateFields,
  TemplateModel,
  TemplateVersionModel,
} from "../db";
import {
  CONTENT_LANGUAGE_HEADER,
  localeOfRequest,
  withTextIn,
} from "../services/localized-text";
import { findCategory, getSettings } from "../services/settings";
import { findStarter, starterFields } from "../services/starters";
import { refreshTemplateAttention } from "../services/template-attention";
import {
  blankContent,
  blankFields,
  contentFieldsOf,
  displayName,
  initializeTemplate,
  refuseTakenSlug,
} from "../services/templates";
import type { TemplateCategory } from "../types";
import type { JsonObject } from "../types/json";

import {
  createTemplateSchema,
  type TemplateDetails,
} from "../validation/templates.schema";
import { isObject, isText } from "../validation/guards";
import { isJsonObject } from "../validation/json";
import { parseBody } from "./body";
import { CategoryDisplay, LocaleChipsDisplay } from "./displays";

const SLUG_IMMUTABLE = "$dms_mailing.errors.slug_immutable";
const SOURCE_NOT_FOUND = "$dms_mailing.errors.template_not_found";
const STARTER_NOT_FOUND = "$dms_mailing.errors.starter_not_found";
export type { TemplateDetails };

export const INVALID_TEMPLATE = "$dms_mailing.errors.invalid_template";
const UNKNOWN_CATEGORY = "$dms_mailing.errors.unknown_category";
const TEMPLATE_IN_USE = "$dms_mailing.errors.template_in_use";
const TEMPLATE_WAS_SENT = "$dms_mailing.errors.template_was_sent";
const MIN_NAME_LENGTH = 1;
const CREATE_ONLY = { edit: ReadonlyBehaviorType.disabled };
/**
 * Read-only columns render as empty dashes on the create form and as raw
 * internal values on the edit one: a template's name, slug and category are
 * the only fields worth asking for.
 */
const NEVER_IN_FORMS = {
  new: ReadonlyBehaviorType.hidden,
  edit: ReadonlyBehaviorType.hidden,
};

const STATUS_ITEMS = ["draft", "live", "archived"].map((value) => ({
  value,
  label: `$dms_mailing.templates.status.${value}`,
}));

/** The template a creation copies from, refused rather than silently ignored. */
async function resolveSource(
  tenantId: string,
  sourceTemplateId: string | undefined,
): Promise<MailingTemplate | undefined> {
  if (!sourceTemplateId) return undefined;
  const source = await GetModel(TemplateModel, tenantId).get(sourceTemplateId);
  if (!source) throw new HTTPResult(HTTP_NOT_FOUND, SOURCE_NOT_FOUND);
  return source;
}

interface TemplateSeed {
  sourceTemplateId?: string;
  starterId?: string;
  category?: string;
}

/** The content fields a creation starts from: a copy, a starter or a blank page. */
async function seedFields(
  tenantId: string,
  seed: TemplateSeed,
  fallbackLocale: string,
): Promise<TemplateFields> {
  const source = await resolveSource(tenantId, seed.sourceTemplateId);
  if (source) return contentFieldsOf(source);
  if (!seed.starterId) {
    return blankFields(
      footerForCategory(blankContent(fallbackLocale), seed.category),
    );
  }
  const starter = findStarter(seed.starterId);
  if (!starter) throw new HTTPResult(HTTP_NOT_FOUND, STARTER_NOT_FOUND);
  return starterFields(starter, fallbackLocale);
}

/** A category is left empty or picked among the ones the settings declare. */
function assertKnownCategory(
  categories: TemplateCategory[],
  category: string | undefined,
): void {
  if (!category || findCategory(categories, category)) return;
  throw new HTTPResult(HTTP_UNPROCESSABLE, UNKNOWN_CATEGORY);
}

/** The key of the row `new` answers since interface-data-api 0.3. */
const createdRowSchema = z.object({ _id: z.string() });

/** The JSON object a creation sends; 400 for any other JSON. */
function parseCreationBody(body: Buffer): JsonObject {
  const parsed = parseBody(body);
  assert(isJsonObject(parsed), HTTP_BAD_REQUEST, INVALID_TEMPLATE);
  return parsed;
}

/**
 * The creation's seed, and the body to store: slug trimmed, and the name
 * typed in the reader's language as every language of the localized field,
 * the fallback one included until someone translates it. A body a guard
 * already parsed arrives as an object. The body to store is handed on as an
 * object: interface-data-api 0.3 refuses a JSON string.
 */
function parseCreation(body: Validation.WrittenBody, locale: string) {
  const raw = Buffer.isBuffer(body) ? parseCreationBody(body) : body;
  const seed = assertValidation(
    raw,
    (value) => createTemplateSchema.parse(value),
    () => INVALID_TEMPLATE,
    HTTP_BAD_REQUEST,
  );
  const normalized = {
    ...raw,
    slug: seed.slug,
    name: withTextIn(undefined, locale, seed.name),
  };
  return { seed, normalized };
}

/** The key that writes every language of a localized field at once. */
const ALL_LANGUAGES = "*";

/**
 * The data API's `new` callback, seeding the template it creates. The
 * module's creation dialogs send one typed name, and the stored name holds
 * every language, written at once: the controller's language key is set to
 * all languages before the creation.
 */
function withSeeding(base: DataControllerCallback): DataControllerCallback {
  return {
    ...base,
    func: async function (
      this: TemplatesTableAPI,
      ctx: RequestContext,
      params: Parameters.NewParameters,
      body: Validation.WrittenBody,
      ...rest: unknown[]
    ) {
      const { seed, normalized } = parseCreation(body, localeOfRequest(ctx));
      const tenantId = getRequestTenantId(ctx);
      const settings = await getSettings(tenantId);
      assertKnownCategory(settings.categories, seed.category);
      const fields = await seedFields(tenantId, seed, settings.fallbackLocale);
      this.language = ALL_LANGUAGES;
      const created: unknown = await refuseTakenSlug(
        Promise.resolve(base.func.call(this, ctx, params, normalized, ...rest)),
      );
      const templateId = createdRowSchema.parse(created)._id;
      const user = await authenticateTenantRequest(ctx);
      await initializeTemplate(tenantId, templateId, displayName(user), fields);
      return created;
    },
  };
}

/** Whether a template was ever sent, a test included. */
async function wasSent(sends: SendModel, slug: string): Promise<boolean> {
  const count = await sends.table.getAll(slug, "templateSlug").count().run();
  return count > 0;
}

/**
 * Why a template cannot go for good, `null` when it can: archived first
 * (archiving explains what stops working), and never sent, since the send log
 * renders past sends from it and a freed slug would inherit their figures.
 */
async function deleteRefusal(
  tenantId: string,
  template: MailingTemplate,
): Promise<string | null> {
  if (template.status !== ARCHIVED_STATUS) return TEMPLATE_IN_USE;
  const isSent = await wasSent(GetModel(SendModel, tenantId), template.slug);
  return isSent ? TEMPLATE_WAS_SENT : null;
}

/** The fields of an edit the guard checks. */
interface TemplateEdit {
  slug?: unknown;
  category?: unknown;
  name?: unknown;
}

/** The field a refused blank name is reported under. */
const BLANK_NAME = { message: INVALID_TEMPLATE, field: "name" };

/** What a guard does once the write it let through is done. */
type AfterWrite = () => Promise<void>;

/** Only an archived template never sent can go. */
export async function assertDeletable(
  tenantId: string,
  model: TemplateModel,
  ids: string[],
): Promise<void> {
  for (const id of ids) {
    const template = await model.get(id);
    const refusal = template && (await deleteRefusal(tenantId, template));
    if (refusal) throw new HTTPResult(HTTP_CONFLICT, refusal);
  }
}

/** A deleted template takes its published versions with it. */
export function afterDelete(tenantId: string, ids: string[]): AfterWrite {
  return async () => {
    const versions = GetModel(TemplateVersionModel, tenantId).table;
    await Promise.all(
      ids.map((id) => versions.getAll(id, "templateId").delete().run()),
    );
    await refreshTemplateAttention(tenantId);
  };
}

/**
 * Sends resolve templates by slug and only the create paths claim it, so a
 * slug never changes once set; a category must be one the settings declare,
 * and a name holds more than spaces.
 */
export async function assertEditable(
  tenantId: string,
  body: TemplateEdit,
  current: Pick<MailingTemplate, "slug">,
): Promise<void> {
  if (body.slug !== undefined && body.slug !== current.slug)
    throw new HTTPResult(HTTP_CONFLICT, SLUG_IMMUTABLE);
  if (body.name !== undefined) {
    const texts = isObject(body.name) ? Object.values(body.name) : [body.name];
    if (!texts.some((text) => isText(text) && text.trim()))
      throw new HTTPResult(HTTP_BAD_REQUEST, BLANK_NAME);
  }
  const { categories } = await getSettings(tenantId);
  const { category } = body;
  if (category === undefined || category === null || category === "") return;
  if (!isText(category))
    throw new HTTPResult(HTTP_UNPROCESSABLE, UNKNOWN_CATEGORY);
  assertKnownCategory(categories, category);
}

/**
 * Saves what the module's drawer and editor change: the name, typed in the
 * reader's language (its other languages kept), and the category.
 */
export async function saveDetails(
  ctx: RequestContext,
  template: MailingTemplate,
  details: TemplateDetails,
  author: string,
): Promise<void> {
  const tenantId = getRequestTenantId(ctx);
  await assertEditable(tenantId, details, template);
  const names = TemplateModel.namesOf(template);
  await GetModel(TemplateModel, tenantId).updateFields(template._id, {
    name: withTextIn(names, localeOfRequest(ctx), details.name),
    ...(details.category !== undefined && {
      category: details.category ?? "",
    }),
    updatedBy: author,
  });
}

/** The names trimmed, blank ones left out, the fallback language filled. */
function tidyNames(names: LocalizedText, locale: string): LocalizedText {
  const tidy = Object.fromEntries(
    Object.entries(names)
      .map(([code, text]) => [code, text.trim()] as const)
      .filter(([, text]) => text),
  );
  if (tidy[LOCALIZED_TEXT_FALLBACK_LOCALE]) return tidy;
  const [first = ""] = Object.values(tidy);
  return { ...tidy, [LOCALIZED_TEXT_FALLBACK_LOCALE]: tidy[locale] ?? first };
}

/**
 * Once an edit of the name is written, stores it trimmed, and gives the
 * fallback language a name when it has none, so every reader sees one.
 */
export function afterEdit(
  model: TemplateModel,
  id: string,
  locale: string,
): AfterWrite {
  return async () => {
    const template = await model.get(id);
    if (!template) return;
    const names = TemplateModel.namesOf(template);
    const tidy = tidyNames(names, locale);
    if (JSON.stringify(tidy) !== JSON.stringify(names))
      await model.updateFields(id, { name: tidy });
  };
}

/** The templates the attention refresh flagged. */
const isFlagged: FilterFunction<TemplatesTableAPI, TemplatesTableAPI> = (
  _context,
  proxy,
) => proxy.default(false).eq(true);

const templateRoutes = {
  ...TableViewRoutes.All,
  new: withSeeding(TableViewRoutes.New),
};

@RegisterDataController()
export class TemplatesTableAPI extends DataController(
  MailingTemplate,
  templateRoutes,
  Controller(`${TABLES_BASE_PATH}/templates`),
) {
  @ModelReference()
  @TenantScopedModel(TemplateModel)
  declare model: TemplateModel;

  @TenantScopedModel(SendModel)
  declare sends: SendModel;

  /** The language names are read, searched, sorted and written in. */
  @Parameter(CONTENT_LANGUAGE_HEADER, "header")
  @ModifierKey(LocalizationModifier)
  declare language: string;

  @Select()
  @Listable()
  @Exported()
  @Access(AccessMode.ReadOnly)
  declare _id: string;

  @Select()
  @Listable()
  @Sortable()
  @Exported()
  @Searchable()
  @Mandatory("new", "edit")
  @Access(AccessMode.ReadWrite)
  @Column({
    name: "$dms_mailing.templates.cols.name",
    type: new DefaultDataTypes.StringType({
      minLength: MIN_NAME_LENGTH,
      maxLength: MAX_NAME_LENGTH,
    }),
  })
  declare name: string;

  @Select()
  @Listable()
  @Sortable()
  @Exported()
  @Searchable()
  @Mandatory("new")
  @Access(AccessMode.ReadWrite)
  @Column({
    name: "$dms_mailing.templates.cols.slug",
    type: new DefaultDataTypes.StringType({ maxLength: MAX_SLUG_LENGTH }),
    readonlyBehavior: CREATE_ONLY,
    display: new DefaultDisplays.MonoDisplay({ copy: true }),
  })
  declare slug: string;

  @Listable()
  @Exported()
  @Access(AccessMode.ReadWrite)
  @Column({
    name: "$dms_mailing.templates.cols.category",
    type: new TemplateCategoryType(),
    filterable: true,
    display: new CategoryDisplay({}),
  })
  declare category: string;

  @Listable()
  @Sortable()
  @Exported()
  @Access(AccessMode.ReadOnly)
  @Column({
    name: "$dms_mailing.templates.cols.status",
    type: new DefaultDataTypes.SelectType({ items: STATUS_ITEMS }),
    filterable: true,
    readonlyBehavior: NEVER_IN_FORMS,
    display: new DefaultDisplays.StatusPillDisplay({
      tones: { live: "success", draft: "neutral", archived: "warning" },
    }),
  })
  declare status: string;

  @Listable()
  @Sortable()
  @Exported()
  @Access(AccessMode.ReadOnly)
  @Column({
    name: "$dms_mailing.templates.cols.updatedAt",
    type: new DefaultDataTypes.DateType({}),
    readonlyBehavior: NEVER_IN_FORMS,
    display: new DefaultDisplays.RelativeDateDisplay({
      style: "day",
      byField: "updatedBy",
      byLabel: "$dms_mailing.templates.cols.updated_by",
    }),
  })
  declare updatedAt: Date;

  @Listable()
  @Exported()
  @Access(AccessMode.ReadOnly)
  @Column({
    name: "$dms_mailing.templates.cols.locales",
    type: new DefaultDataTypes.StringType({}),
    readonlyBehavior: NEVER_IN_FORMS,
    display: new LocaleChipsDisplay({}),
  })
  declare locales: string;

  @Listable()
  @Exported()
  @Access(AccessMode.ReadOnly)
  @Column({
    name: "$dms_mailing.templates.cols.updatedBy",
    type: new DefaultDataTypes.StringType({}),
    readonlyBehavior: NEVER_IN_FORMS,
  })
  declare updatedBy: string;

  @Listable()
  @Access(AccessMode.ReadOnly)
  @Column({
    name: "$dms_mailing.templates.cols.publishedVersion",
    type: new DefaultDataTypes.NumberType({}),
    readonlyBehavior: NEVER_IN_FORMS,
    isVisible: false,
  })
  declare publishedVersion: number;

  @Listable()
  @Access(AccessMode.ReadOnly)
  @Column({
    name: "$dms_mailing.templates.cols.isDraftPending",
    type: new DefaultDataTypes.BooleanType({}),
    readonlyBehavior: NEVER_IN_FORMS,
    isVisible: false,
  })
  declare isDraftPending: boolean;

  @Listable()
  @Access(AccessMode.ReadOnly)
  @Column({
    name: "$dms_mailing.templates.cols.publishedAt",
    type: new DefaultDataTypes.DateType({}),
    readonlyBehavior: NEVER_IN_FORMS,
    isVisible: false,
  })
  declare publishedAt: Date;

  /** Why the template needs a look (comma-separated), for the gallery cards. */
  @Listable()
  @Access(AccessMode.ReadOnly)
  declare attention: string;

  /** What the "Needs attention" tab filters on, whatever value it names. */
  @Filter(isFlagged)
  @Access(AccessMode.ReadOnly)
  declare needsAttention: boolean;

  /**
   * Whether an archived template was ever sent: the gallery then offers no
   * Delete, which the route would refuse. Read for archived rows only, the
   * only ones Delete is offered on.
   */
  @Listable(["slug", "status"])
  @Access(AccessMode.ReadOnly)
  get hasSends(): Promise<boolean> | boolean {
    if (this.status !== ARCHIVED_STATUS || !this.sends) return false;
    return wasSent(this.sends, this.slug);
  }
}
